﻿using System;



namespace Orion
{
    public class UCI
    {
        static String ENGINENAME = "Orion v1";
        public static void uciCommunication()
        {
            //Scanner input = new Scanner(System.in);
            while (true)
            {
               
                String inputString = Console.ReadLine();
                if ("uci".Equals(inputString))
                {
                    inputUCI();
                }
                else if (inputString.StartsWith("setoption"))
                {
                    inputSetOption(inputString);
                }
                else if ("isready".Equals(inputString))
                {
                    inputIsReady();
                }
                else if ("ucinewgame".Equals(inputString))
                {
                    inputUCINewGame();
                }
                else if (inputString.StartsWith("position"))
                {
                    inputPosition(inputString);
                }
                else if (inputString.StartsWith("go"))
                {
                    inputGo();
                }
                else if (inputString.StartsWith("zerar"))
                {
                    Bench.zerar();
                }
                else if (inputString.Equals("quit"))
                {
                    Bench.bench();
                    inputQuit();
                   
                }
                else if ("print".Equals(inputString))
                {
                    inputPrint();
                }
            }
        }
        public static void inputUCI()
        {
            Console.WriteLine("id name " + ENGINENAME);
            Console.WriteLine("id author Valdinei");
            //options go here
            Console.WriteLine("uciok");
        }
        public static void inputSetOption(String inputString)
        {
            //set options
        }
        public static void inputIsReady()
        {
            Console.WriteLine("readyok");
        }
        public static void inputUCINewGame()
        {
            //BoardGeneration.importFEN("rn4rk/pp4pp/1qp5/3np3/4N1NP/2PP4/PP3P2/R3K2R w KQ - 2 2 ");
            BoardGeneration.importFEN("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
            //BoardGeneration.importFEN("1r6/3k4/8/3p4/5P2/2p5/P7/4K3 w - - 0 27");
        }
        public static void inputPosition(String input)
        {
            
            input = input.Substring(9) + " ";
            if (input.Contains("startpos "))
            {
                input = input.Substring(9);
                //BoardGeneration.importFEN("rn4rk/pp4pp/1qp5/3np3/4N1NP/2PP4/PP3P2/R3K2R w KQ - 2 2 ");
                BoardGeneration.importFEN("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
                //BoardGeneration.importFEN("1r6/3k4/8/3p4/5P2/2p5/P7/4K3 w - - 0 27");
                
            }
            else if (input.Contains("fen"))
            {
                input = input.Substring(4);
                BoardGeneration.importFEN(input);
            }
            if (input.Contains("moves"))
            {
                input = input.Substring(input.IndexOf("moves") + 6);
                while (input.Length > 0)
                {
                    String moves;
                    if (Orion.WhiteToMove)
                    {
                        moves = Moves.possibleMovesW(Orion.WP, Orion.WN, Orion.WB, Orion.WR, Orion.WQ, Orion.WK, Orion.BP, Orion.BN, Orion.BB, Orion.BR, Orion.BQ, Orion.BK, Orion.EP, Orion.CWK, Orion.CWQ, Orion.CBK, Orion.CBQ);
                    }
                    else
                    {
                        moves = Moves.possibleMovesB(Orion.WP, Orion.WN, Orion.WB, Orion.WR, Orion.WQ, Orion.WK, Orion.BP, Orion.BN, Orion.BB, Orion.BR, Orion.BQ, Orion.BK, Orion.EP, Orion.CWK, Orion.CWQ, Orion.CBK, Orion.CBQ);
                    }
                    
                    algebraToMove(input, moves);
                    input = input.Substring(input.IndexOf(' ') + 1);
                }
            }
        }
        public static void inputGo()
        {
            
            String move;
            if (Orion.WhiteToMove)
            {
                move = Moves.possibleMovesW(Orion.WP, Orion.WN, Orion.WB, Orion.WR, Orion.WQ, Orion.WK, Orion.BP, Orion.BN, Orion.BB, Orion.BR, Orion.BQ, Orion.BK, Orion.EP, Orion.CWK, Orion.CWQ, Orion.CBK, Orion.CBQ);
            }
            else
            {
                move = Moves.possibleMovesB(Orion.WP, Orion.WN, Orion.WB, Orion.WR, Orion.WQ, Orion.WK, Orion.BP, Orion.BN, Orion.BB, Orion.BR, Orion.BQ, Orion.BK, Orion.EP, Orion.CWK, Orion.CWQ, Orion.CBK, Orion.CBQ);
            }

            //aqui ele fazia o movimento randomico:
            //int index = (int)(Math.Floor(new Random().NextDouble() * (move.Length / 4)) * 4); //aqui foi usado NextDouble para ficar igual o do Java

            Bench.chamadas[Bench.PVSEARCH]++;
            Bench.ms[Bench.PVSEARCH].Start();
            int score = PrincipalVariation.pvSearch(-1000, 1000, Orion.WP, Orion.WN, Orion.WB, Orion.WR, Orion.WQ, Orion.WK, Orion.BP, Orion.BN, Orion.BB, Orion.BR, Orion.BQ, Orion.BK, Orion.EP, Orion.CWK, Orion.CWQ, Orion.CBK, Orion.CBQ, Orion.WhiteToMove, 0);
            int index = PrincipalVariation.bestMoveIndex;
            Bench.ms[Bench.PVSEARCH].Stop();
            //Console.WriteLine("score " + score);
            Console.WriteLine("bestmove " + moveToAlgebra(move.Substring(index, 4)));
            
        }
        public static String moveToAlgebra(String move)
        {
            String append = "";
            int start = 0, end = 0;
            if (Char.IsDigit(move.ToCharArray()[3]))
            {//'regular' move
                start = (int)((Char.GetNumericValue(move.ToCharArray()[0]) * 8) + (Char.GetNumericValue(move.ToCharArray()[1])));
                end = (int)((Char.GetNumericValue(move.ToCharArray()[2]) * 8) + (Char.GetNumericValue(move.ToCharArray()[3])));
            }
            else if (move.ToCharArray()[3] == 'P')
            {//pawn promotion
                if (Char.IsUpper(move.ToCharArray()[2]))
                {
                    start = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[move.ToCharArray()[0] - '0'] & Moves.RankMasks8[1]);
                    end = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[move.ToCharArray()[1] - '0'] & Moves.RankMasks8[0]);
                }
                else
                {
                    start = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[move.ToCharArray()[0] - '0'] & Moves.RankMasks8[6]);
                    end = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[move.ToCharArray()[1] - '0'] & Moves.RankMasks8[7]);
                }
                append = "" + Char.ToLower(move.ToCharArray()[2]);
            }
            else if (move.ToCharArray()[3] == 'E')
            {//en passant
                if (move.ToCharArray()[2] == 'W')
                {
                    start = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[move.ToCharArray()[0] - '0'] & Moves.RankMasks8[3]);
                    end = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[move.ToCharArray()[1] - '0'] & Moves.RankMasks8[2]);
                }
                else
                {
                    start = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[move.ToCharArray()[0] - '0'] & Moves.RankMasks8[4]);
                    end = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[move.ToCharArray()[1] - '0'] & Moves.RankMasks8[5]);
                }
            }
            String returnMove = "";
            returnMove += (char)('a' + (start % 8));
            returnMove += (char)('8' - (start / 8));
            returnMove += (char)('a' + (end % 8));
            returnMove += (char)('8' - (end / 8));
            returnMove += append;
            return returnMove;
        }
        public static void algebraToMove(String input, String moves)
        {
            int start = 0, end = 0;
            int from = (input.ToCharArray()[0] - 'a') + (8 * ('8' - input.ToCharArray()[1]));
            int to = (input.ToCharArray()[2] - 'a') + (8 * ('8' - input.ToCharArray()[3]));
            for (int i = 0; i < moves.Length; i += 4)
            {
                if (Char.IsDigit(moves.ToCharArray()[i + 3]))
                {//'regular' move
                    start = (int)((Char.GetNumericValue(moves.ToCharArray()[i + 0]) * 8) + (Char.GetNumericValue(moves.ToCharArray()[i + 1])));
                    end = (int)((Char.GetNumericValue(moves.ToCharArray()[i + 2]) * 8) + (Char.GetNumericValue(moves.ToCharArray()[i + 3])));
                }
                else if (moves.ToCharArray()[i + 3] == 'P')
                {//pawn promotion
                    if (Char.IsUpper(moves.ToCharArray()[i + 2]))
                    {
                        start = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[moves.ToCharArray()[i + 0] - '0'] & Moves.RankMasks8[1]);
                        end = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[moves.ToCharArray()[i + 1] - '0'] & Moves.RankMasks8[0]);
                    }
                    else
                    {
                        start = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[moves.ToCharArray()[i + 0] - '0'] & Moves.RankMasks8[6]);
                        end = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[moves.ToCharArray()[i + 1] - '0'] & Moves.RankMasks8[7]);
                    }
                }
                else if (moves.ToCharArray()[i + 3] == 'E')
                {//en passant
                    if (moves.ToCharArray()[i + 2] == 'W')
                    {
                        start = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[moves.ToCharArray()[i + 0] - '0'] & Moves.RankMasks8[3]);
                        end = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[moves.ToCharArray()[i + 1] - '0'] & Moves.RankMasks8[2]);
                    }
                    else
                    {
                        start = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[moves.ToCharArray()[i + 0] - '0'] & Moves.RankMasks8[4]);
                        end = LongExtensions.NumberOfTrailingZeros(Moves.FileMasks8[moves.ToCharArray()[i + 1] - '0'] & Moves.RankMasks8[5]);
                    }
                }
                   
                if ((start == from) && (end == to))
                {
                    ///Console.WriteLine(moves.Substring(i,4));
                    if ((input.ToCharArray()[4] == ' ') || (Char.ToUpper(input.ToCharArray()[4]) == Char.ToUpper(moves.ToCharArray()[i + 2])))
                    {

                        if (Char.IsDigit(moves.ToCharArray()[i + 3]))
                        {//'regular' move
                            start = (int)((Char.GetNumericValue(moves.ToCharArray()[i]) * 8) + (Char.GetNumericValue(moves.ToCharArray()[i + 1])));
                            if ((((ulong)1L << start) & Orion.WK) != 0) { Orion.CWK = false; Orion.CWQ = false; }
                            else if ((((ulong)1L << start) & Orion.BK) != 0) { Orion.CBK = false; Orion.CBQ = false; }
                            else if ((((ulong)1L << start) & Orion.WR & ((ulong)1L << 63)) != 0) { Orion.CWK = false; }
                            else if ((((ulong)1L << start) & Orion.WR & ((ulong)1L << 56)) != 0) { Orion.CWQ = false; }
                            else if ((((ulong)1L << start) & Orion.BR & ((ulong)1L << 7)) != 0) { Orion.CBK = false; }
                            else if ((((ulong)1L << start) & Orion.BR & 1L) != 0) { Orion.CBQ = false; }
                        }
                        Orion.EP = (Moves.makeMoveEP(Orion.WP | Orion.BP, moves.Substring(i, 4)));
                        Orion.WR = (Moves.makeMoveCastle(Orion.WR, Orion.WK | Orion.BK, moves.Substring(i, 4), 'R'));
                        Orion.BR = (Moves.makeMoveCastle(Orion.BR, Orion.WK | Orion.BK, moves.Substring(i, 4), 'r'));
                        Orion.WP = (Moves.makeMove(Orion.WP, moves.Substring(i, 4), 'P'));
                        Orion.WN = (Moves.makeMove(Orion.WN, moves.Substring(i, 4), 'N'));
                        Orion.WB = (Moves.makeMove(Orion.WB, moves.Substring(i, 4), 'B'));
                        Orion.WR = (Moves.makeMove(Orion.WR, moves.Substring(i, 4), 'R'));
                        Orion.WQ = (Moves.makeMove(Orion.WQ, moves.Substring(i, 4), 'Q'));
                        Orion.WK = (Moves.makeMove(Orion.WK, moves.Substring(i, 4), 'K'));
                        Orion.BP = (Moves.makeMove(Orion.BP, moves.Substring(i, 4), 'p'));
                        Orion.BN = (Moves.makeMove(Orion.BN, moves.Substring(i, 4), 'n'));
                        Orion.BB = (Moves.makeMove(Orion.BB, moves.Substring(i, 4), 'b'));
                        Orion.BR = (Moves.makeMove(Orion.BR, moves.Substring(i, 4), 'r'));
                        Orion.BQ = (Moves.makeMove(Orion.BQ, moves.Substring(i, 4), 'q'));
                        Orion.BK = (Moves.makeMove(Orion.BK, moves.Substring(i, 4), 'k'));
                        Orion.WhiteToMove = !Orion.WhiteToMove;
                        
                        break;
                    }
                }
            }
        }
        public static void inputQuit()
        {
            Console.ReadKey();
            System.Environment.Exit(0);
        }
        public static void inputPrint()
        {
            BoardGeneration.drawArray(Orion.WP, Orion.WN, Orion.WB, Orion.WR, Orion.WQ, Orion.WK, Orion.BP, Orion.BN, Orion.BB, Orion.BR, Orion.BQ, Orion.BK);
            //Console.WriteLine("Zobrist Hash: ");
            //Console.WriteLine(Zobrist.getZobristHash(Orion.WP, Orion.WN, Orion.WB, Orion.WR, Orion.WQ, Orion.WK, Orion.BP, Orion.BN, Orion.BB, Orion.BR, Orion.BQ, Orion.BK, Orion.EP, Orion.CWK, Orion.CWQ, Orion.CBK, Orion.CBQ, Orion.WhiteToMove));
        }
    }
}
