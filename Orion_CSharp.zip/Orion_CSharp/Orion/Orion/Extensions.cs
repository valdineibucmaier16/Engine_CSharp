﻿namespace Orion
{
    public static class LongExtensions
    {

        public static ulong Reverse(ulong i)
        {
            i = (i & 0x5555555555555555L) << 1 | (i >> 1) & 0x5555555555555555L;
            i = (i & 0x3333333333333333L) << 2 | (i >> 2) & 0x3333333333333333L;
            i = (i & 0x0f0f0f0f0f0f0f0fL) << 4 | (i >> 4) & 0x0f0f0f0f0f0f0f0fL;
            i = (i & 0x00ff00ff00ff00ffL) << 8 | (i >> 8) & 0x00ff00ff00ff00ffL;
            i = (i << 48) | ((i & 0xffff0000L) << 16) |

                ((i >> 16) & 0xffff0000L) | (i >> 48);
            return i;
        }

        public static int NumberOfTrailingZeros(ulong i)
        {
            uint x, y;
            if (i == 0) return 64;
            uint n = 63;

            y = (uint)i; if (y != 0) { n = n - 32; x = y; } else x = (uint)(i >> 32);
            y = x << 16; if (y != 0) { n = n - 16; x = y; }
            y = x << 8; if (y != 0) { n = n - 8; x = y; }
            y = x << 4; if (y != 0) { n = n - 4; x = y; }
            y = x << 2; if (y != 0) { n = n - 2; x = y; }

            uint x1 = x << 1;
            uint xr = (x1 >> 31);
            uint index = n - xr;
            return (int)index;
        }


        public static long LongShiftRight(long i, int bits)
        {
            return (long)((ulong)i >> bits);
        }

        public static long LongShiftLeft(long i, int bits)
        {
            return (long)((ulong)i << bits);
        }
    }
}
