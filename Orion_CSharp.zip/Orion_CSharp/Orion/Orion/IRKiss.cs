﻿using System.Collections.Generic;

namespace Orion
{
    public interface IRKiss
    {
        IEnumerable<ulong> Get(int count);

        ulong Rand();

        /// Special generator used to fast init magic numbers.
        /// Output values only have 1/8th of their bits set on average.
        ulong Sparse();
    }
}
