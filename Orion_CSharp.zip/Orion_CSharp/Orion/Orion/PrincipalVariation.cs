﻿using System;


namespace Orion
{
    public class PrincipalVariation
    {
        public static int bestMoveIndex;

        public static int zWSearch(int beta, ulong WP, ulong WN, ulong WB, ulong WR, ulong WQ, ulong WK, ulong BP, ulong BN, ulong BB, ulong BR, ulong BQ, ulong BK, ulong EP, bool CWK, bool CWQ, bool CBK, bool CBQ, bool WhiteToMove, int depth)
        {

            //fail-hard zero window search, returns either beta-1 or beta
            int score = Int32.MinValue;
            //alpha == beta - 1
            //this is either a cut- or all-node
            String moves;
            if (WhiteToMove)
            {
                moves = Moves.possibleMovesW(WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK, EP, CWK, CWQ, CBK, CBQ);
            }
            else
            {
                moves = Moves.possibleMovesB(WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK, EP, CWK, CWQ, CBK, CBQ);
            }
            if (depth == Orion.searchDepth)
            {
                score = Rating.evaluate(moves.Length, depth);

                return score;
            }

            //sortMoves();
            for (int i = 0; i < moves.Length; i += 4)
            {
                ulong WPt = (Moves.makeMove(WP, moves.Substring(i, 4), 'P')), WNt = (Moves.makeMove(WN, moves.Substring(i, 4), 'N')),
                        WBt = (Moves.makeMove(WB, moves.Substring(i, 4), 'B')), WRt = (Moves.makeMove(WR, moves.Substring(i, 4), 'R')),
                        WQt = (Moves.makeMove(WQ, moves.Substring(i, 4), 'Q')), WKt = (Moves.makeMove(WK, moves.Substring(i, 4), 'K')),
                        BPt = (Moves.makeMove(BP, moves.Substring(i, 4), 'p')), BNt = (Moves.makeMove(BN, moves.Substring(i, 4), 'n')),
                        BBt = (Moves.makeMove(BB, moves.Substring(i, 4), 'b')), BRt = (Moves.makeMove(BR, moves.Substring(i, 4), 'r')),
                        BQt = (Moves.makeMove(BQ, moves.Substring(i, 4), 'q')), BKt = (Moves.makeMove(BK, moves.Substring(i, 4), 'k')),
                        EPt = (Moves.makeMoveEP(WP | BP, moves.Substring(i, 4)));
                WRt = (Moves.makeMoveCastle(WRt, WK | BK, moves.Substring(i, 4), 'R'));
                BRt = (Moves.makeMoveCastle(BRt, WK | BK, moves.Substring(i, 4), 'r'));
                bool CWKt = CWK, CWQt = CWQ, CBKt = CBK, CBQt = CBQ;
                if (Char.IsDigit(moves.ToCharArray()[i + 3]))
                {//'regular' move
                    int start = (int)((Char.GetNumericValue(moves.ToCharArray()[i]) * 8) + (Char.GetNumericValue(moves.ToCharArray()[i + 1])));
                    if ((((ulong)1L << start) & WK) != 0) { CWKt = false; CWQt = false; }
                    else if ((((ulong)1L << start) & BK) != 0) { CBKt = false; CBQt = false; }
                    else if ((((ulong)1L << start) & WR & ((ulong)1L << 63)) != 0) { CWKt = false; }
                    else if ((((ulong)1L << start) & WR & (1L << 56)) != 0) { CWQt = false; }
                    else if ((((ulong)1L << start) & BR & (1L << 7)) != 0) { CBKt = false; }
                    else if ((((ulong)1L << start) & BR & 1L) != 0) { CBQt = false; }
                }

                if (((WKt & Moves.unsafeForWhite(WPt, WNt, WBt, WRt, WQt, WKt, BPt, BNt, BBt, BRt, BQt, BKt)) == 0 && WhiteToMove) ||
                        ((BKt & Moves.unsafeForBlack(WPt, WNt, WBt, WRt, WQt, WKt, BPt, BNt, BBt, BRt, BQt, BKt)) == 0 && !WhiteToMove))
                {

                    score = -zWSearch(1 - beta, WPt, WNt, WBt, WRt, WQt, WKt, BPt, BNt, BBt, BRt, BQt, BKt, EPt, CWKt, CWQt, CBKt, CBQt, !WhiteToMove, depth + 1);

                }
                if (score >= beta)
                {
                    return score;//fail-hard beta-cutoff
                }
            }

            return beta - 1;//fail-hard, return alpha
        }
        public static int getFirstLegalMove(String moves, ulong WP, ulong WN, ulong WB, ulong WR, ulong WQ, ulong WK, ulong BP, ulong BN, ulong BB, ulong BR, ulong BQ, ulong BK, ulong EP, bool CWK, bool CWQ, bool CBK, bool CBQ, bool WhiteToMove)
        {
            Bench.chamadas[Bench.GETFIRSTLEGALMOVE]++;

            Bench.ms[Bench.GETFIRSTLEGALMOVE].Start();

            Bench.msAux[Bench.GETFIRSTLEGALMOVE].Restart();

            for (int i = 0; i < moves.Length; i += 4)
            {
                ulong WPt = (Moves.makeMove(WP, moves.Substring(i, 4), 'P')), WNt = (Moves.makeMove(WN, moves.Substring(i, 4), 'N')),
                        WBt = (Moves.makeMove(WB, moves.Substring(i, 4), 'B')), WRt = (Moves.makeMove(WR, moves.Substring(i, 4), 'R')),
                        WQt = (Moves.makeMove(WQ, moves.Substring(i, 4), 'Q')), WKt = (Moves.makeMove(WK, moves.Substring(i, 4), 'K')),
                        BPt = (Moves.makeMove(BP, moves.Substring(i, 4), 'p')), BNt = (Moves.makeMove(BN, moves.Substring(i, 4), 'n')),
                        BBt = (Moves.makeMove(BB, moves.Substring(i, 4), 'b')), BRt = (Moves.makeMove(BR, moves.Substring(i, 4), 'r')),
                        BQt = (Moves.makeMove(BQ, moves.Substring(i, 4), 'q')), BKt = (Moves.makeMove(BK, moves.Substring(i, 4), 'k'));
                WRt = (Moves.makeMoveCastle(WRt, WK | BK, moves.Substring(i, 4), 'R'));
                BRt = (Moves.makeMoveCastle(BRt, WK | BK, moves.Substring(i, 4), 'r'));
                if (((WKt & Moves.unsafeForWhite(WPt, WNt, WBt, WRt, WQt, WKt, BPt, BNt, BBt, BRt, BQt, BKt)) == 0 && WhiteToMove) ||
                        ((BKt & Moves.unsafeForBlack(WPt, WNt, WBt, WRt, WQt, WKt, BPt, BNt, BBt, BRt, BQt, BKt)) == 0 && !WhiteToMove))
                {
                    Bench.ms[Bench.GETFIRSTLEGALMOVE].Stop();

                    Bench.msAux[Bench.GETFIRSTLEGALMOVE].Stop();
                    Bench.MenorMaior(Bench.GETFIRSTLEGALMOVE);
                    return i;
                }
            }

            Bench.ms[Bench.GETFIRSTLEGALMOVE].Stop();

            Bench.msAux[Bench.GETFIRSTLEGALMOVE].Stop();
            Bench.MenorMaior(Bench.GETFIRSTLEGALMOVE);
            return -1;
        }
        public static int pvSearch(int alpha, int beta, ulong WP, ulong WN, ulong WB, ulong WR, ulong WQ, ulong WK, ulong BP, ulong BN, ulong BB, ulong BR, ulong BQ, ulong BK, ulong EP, bool CWK, bool CWQ, bool CBK, bool CBQ, bool WhiteToMove, int depth)
        {

            Bench.msAux[Bench.PVSEARCH].Restart();

            //using fail soft with negamax
            int bestScore;
            bestMoveIndex = -1;

            String moves;
            if (WhiteToMove)
            {
                moves = Moves.possibleMovesW(WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK, EP, CWK, CWQ, CBK, CBQ);

            }
            else
            {
                moves = Moves.possibleMovesB(WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK, EP, CWK, CWQ, CBK, CBQ);

            }

            if (depth == Orion.searchDepth)
            {
                bestScore = Rating.evaluate(moves.Length, depth); //adicionei aqui o eval

                Bench.msAux[Bench.PVSEARCH].Stop();
                Bench.MenorMaior(Bench.PVSEARCH);
                return bestScore;
            }

            //sortMoves();
            int firstLegalMove = getFirstLegalMove(moves, WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK, EP, CWK, CWQ, CBK, CBQ, WhiteToMove);
            if (firstLegalMove == -1)
            {
                Bench.msAux[Bench.PVSEARCH].Stop();
                Bench.MenorMaior(Bench.PVSEARCH);

                return WhiteToMove ? Orion.MATE_SCORE : -Orion.MATE_SCORE;
            }
            ulong WPt = (Moves.makeMove(WP, moves.Substring(firstLegalMove, 4), 'P')), WNt = (Moves.makeMove(WN, moves.Substring(firstLegalMove, 4), 'N')),
                    WBt = (Moves.makeMove(WB, moves.Substring(firstLegalMove, 4), 'B')), WRt = (Moves.makeMove(WR, moves.Substring(firstLegalMove, 4), 'R')),
                    WQt = (Moves.makeMove(WQ, moves.Substring(firstLegalMove, 4), 'Q')), WKt = (Moves.makeMove(WK, moves.Substring(firstLegalMove, 4), 'K')),
                    BPt = (Moves.makeMove(BP, moves.Substring(firstLegalMove, 4), 'p')), BNt = (Moves.makeMove(BN, moves.Substring(firstLegalMove, 4), 'n')),
                    BBt = (Moves.makeMove(BB, moves.Substring(firstLegalMove, 4), 'b')), BRt = (Moves.makeMove(BR, moves.Substring(firstLegalMove, 4), 'r')),
                    BQt = (Moves.makeMove(BQ, moves.Substring(firstLegalMove, 4), 'q')), BKt = (Moves.makeMove(BK, moves.Substring(firstLegalMove, 4), 'k')),
                    EPt = (Moves.makeMoveEP(WP | BP, moves.Substring(firstLegalMove, 4)));
            WRt = (Moves.makeMoveCastle(WRt, WK | BK, moves.Substring(firstLegalMove, 4), 'R'));
            BRt = (Moves.makeMoveCastle(BRt, WK | BK, moves.Substring(firstLegalMove, 4), 'r'));
            bool CWKt = CWK, CWQt = CWQ, CBKt = CBK, CBQt = CBQ;
            if (Char.IsDigit(moves.ToCharArray()[firstLegalMove + 3]))
            {//'regular' move
                int start = (int)((Char.GetNumericValue(moves.ToCharArray()[firstLegalMove]) * 8) + (Char.GetNumericValue(moves.ToCharArray()[firstLegalMove + 1])));
                if ((((ulong)1L << start) & WK) != 0) { CWKt = false; CWQt = false; }
                else if ((((ulong)1L << start) & BK) != 0) { CBKt = false; CBQt = false; }
                else if ((((ulong)1L << start) & WR & ((ulong)1L << 63)) != 0) { CWKt = false; }
                else if ((((ulong)1L << start) & WR & ((ulong)1L << 56)) != 0) { CWQt = false; }
                else if ((((ulong)1L << start) & BR & ((ulong)1L << 7)) != 0) { CBKt = false; }
                else if ((((ulong)1L << start) & BR & 1L) != 0) { CBQt = false; }
            }


            Bench.msAux[Bench.PVSEARCH].Stop();

            bestScore = -pvSearch(-beta, -alpha, WPt, WNt, WBt, WRt, WQt, WKt, BPt, BNt, BBt, BRt, BQt, BKt, EPt, CWKt, CWQt, CBKt, CBQt, !WhiteToMove, depth + 1);

            Bench.msAux[Bench.PVSEARCH].Start();
            Orion.moveCounter++;
            if (Math.Abs(bestScore) == Orion.MATE_SCORE)
            {

                Bench.msAux[Bench.PVSEARCH].Stop();
                Bench.MenorMaior(Bench.PVSEARCH);

                return bestScore;
            }
            if (bestScore > alpha)
            {
                if (bestScore >= beta)
                {
                    //This is a refutation move
                    //It is not a PV move
                    //However, it will usually cause a cutoff so it can
                    //be considered a best move if no other move is found
                    //Bench.ms[Bench.PVSEARCH].Stop();

                    Bench.msAux[Bench.PVSEARCH].Stop();
                    Bench.MenorMaior(Bench.PVSEARCH);

                    return bestScore;
                }
                alpha = bestScore;
            }

            bestMoveIndex = firstLegalMove;

            for (int i = firstLegalMove + 4; i < moves.Length; i += 4)
            {
                int score;
                Orion.moveCounter++;
                //legal, non-castle move
                WPt = (Moves.makeMove(WP, moves.Substring(i, 4), 'P'));
                WNt = (Moves.makeMove(WN, moves.Substring(i, 4), 'N'));
                WBt = (Moves.makeMove(WB, moves.Substring(i, 4), 'B'));
                WRt = (Moves.makeMove(WR, moves.Substring(i, 4), 'R'));
                WQt = (Moves.makeMove(WQ, moves.Substring(i, 4), 'Q'));
                WKt = (Moves.makeMove(WK, moves.Substring(i, 4), 'K'));
                BPt = (Moves.makeMove(BP, moves.Substring(i, 4), 'p'));
                BNt = (Moves.makeMove(BN, moves.Substring(i, 4), 'n'));
                BBt = (Moves.makeMove(BB, moves.Substring(i, 4), 'b'));
                BRt = (Moves.makeMove(BR, moves.Substring(i, 4), 'r'));
                BQt = (Moves.makeMove(BQ, moves.Substring(i, 4), 'q'));
                BKt = (Moves.makeMove(BK, moves.Substring(i, 4), 'k'));
                EPt = (Moves.makeMoveEP(WP | BP, moves.Substring(i, 4)));
                WRt = (Moves.makeMoveCastle(WRt, WK | BK, moves.Substring(i, 4), 'R'));
                BRt = (Moves.makeMoveCastle(BRt, WK | BK, moves.Substring(i, 4), 'r'));
                CWKt = CWK;
                CWQt = CWQ;
                CBKt = CBK;
                CBQt = CBQ;
                if (Char.IsDigit(moves.ToCharArray()[i + 3]))
                {//'regular' move
                    int start = (int)((Char.GetNumericValue(moves.ToCharArray()[i]) * 8) + (Char.GetNumericValue(moves.ToCharArray()[i + 1])));
                    if ((((ulong)1L << start) & WK) != 0) { CWKt = false; CWQt = false; }
                    else if ((((ulong)1L << start) & BK) != 0) { CBKt = false; CBQt = false; }
                    else if ((((ulong)1L << start) & WR & ((ulong)1L << 63)) != 0) { CWKt = false; }
                    else if ((((ulong)1L << start) & WR & ((ulong)1L << 56)) != 0) { CWQt = false; }
                    else if ((((ulong)1L << start) & BR & ((ulong)1L << 7)) != 0) { CBKt = false; }
                    else if ((((ulong)1L << start) & BR & 1L) != 0) { CBQt = false; }
                }

                Bench.chamadas[Bench.ZWSEARCH]++;
                Bench.ms[Bench.ZWSEARCH].Start();
                Bench.msAux[Bench.ZWSEARCH].Restart();

                score = -zWSearch(-alpha, WPt, WNt, WBt, WRt, WQt, WKt, BPt, BNt, BBt, BRt, BQt, BKt, EPt, CWKt, CWQt, CBKt, CBQt, !WhiteToMove, depth + 1);

                Bench.msAux[Bench.ZWSEARCH].Stop();
                Bench.MenorMaior(Bench.ZWSEARCH);
                Bench.zWSearch.Add(Bench.msAux[Bench.ZWSEARCH].ElapsedTicks * 100);
                Bench.ms[Bench.ZWSEARCH].Stop();

                if ((score > alpha) && (score < beta))
                {
                    //research with window [alpha;beta]
                    Bench.msAux[Bench.PVSEARCH].Stop();

                    bestScore = -pvSearch(-beta, -alpha, WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK, EP, CWK, CWQ, CBK, CBQ, !WhiteToMove, depth + 1);

                    Bench.msAux[Bench.PVSEARCH].Start();
                    if (score > alpha)
                    {
                        bestMoveIndex = i;
                        alpha = score;
                    }
                }
                if ((score != Orion.NULL_INT) && (score > bestScore))
                {
                    if (score >= beta)
                    {

                        Bench.msAux[Bench.PVSEARCH].Stop();
                        Bench.MenorMaior(Bench.PVSEARCH);

                        return score;
                    }
                    bestScore = score;
                    if (Math.Abs(bestScore) == Orion.MATE_SCORE)
                    {

                        Bench.msAux[Bench.PVSEARCH].Stop();
                        Bench.MenorMaior(Bench.PVSEARCH);

                        return bestScore;
                    }
                }
            }

            Bench.msAux[Bench.PVSEARCH].Stop();
            Bench.MenorMaior(Bench.PVSEARCH);

            return bestScore;
        }
    }
}
