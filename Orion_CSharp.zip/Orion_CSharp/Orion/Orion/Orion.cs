﻿using System;


namespace Orion
{
   public class Orion
    {
        public static ulong WP = 0L, WN = 0L, WB = 0L, WR = 0L, WQ = 0L, WK = 0L, BP = 0L, BN = 0L, BB = 0L, BR = 0L, BQ = 0L, BK = 0L, EP = 0L; //mudei para ulong
        public static bool CWK = true, CWQ = true, CBK = true, CBQ = true, WhiteToMove = true;//true=castle is possible
        public static long UniversalWP = 0L, UniversalWN = 0L, UniversalWB = 0L, UniversalWR = 0L,
                UniversalWQ = 0L, UniversalWK = 0L, UniversalBP = 0L, UniversalBN = 0L,
                UniversalBB = 0L, UniversalBR = 0L, UniversalBQ = 0L, UniversalBK = 0L,
                UniversalEP = 0L;
        public static int searchDepth = 5, moveCounter;
        public static int MATE_SCORE = 5000, NULL_INT = Int32.MinValue;
        public static void Main(String[] args)
        {
            //Zobrist.random64();
            //Zobrist.testDistribution();
            Zobrist.zobristFillArray();
            Bench.InitiateBench();
            //BoardGeneration.importFEN("1r6/3k4/8/3p4/5P2/2p5/P7/4K3 w - - 0 27");
            //BoardGeneration.importFEN("rn4rk/pp4pp/1qp5/3np3/4N1NP/2PP4/PP3P2/R3K2R w KQ - 2 2 ");
            //UCI.inputPrint();
            //UCI.inputPrint();
            BoardGeneration.importFEN("rnbqkbnr/ppp1pppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1");
            //UCI.inputPrint();
            // var EllapsedTime = Stopwatch.StartNew();
            //Console.WriteLine(PrincipalVariation.pvSearch(-1000, 1000, WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK, EP, CWK, CWQ, CBK, CBQ, WhiteToMove, 0));
            //EllapsedTime.Stop();
            //Console.WriteLine("That took " + EllapsedTime.ElapsedMilliseconds + " milliseconds"); 
            UCI.uciCommunication();
        }

       
    }
}
