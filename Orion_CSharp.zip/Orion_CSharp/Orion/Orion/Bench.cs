﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace Orion
{
    class Bench
    {
        public const int FLIPBOARD = 0;
        public const int KINGSAFE = 1;

        public const int RATE_ATTACK = 2;
        public const int RATE_MATERIAL = 3;
        public const int RATE_MOVEABLITLY = 4;
        public const int RATE_POSITIONAL = 5;
        public const int EVALUATE = 6;

        public const int ZWSEARCH = 7;
        public const int GETFIRSTLEGALMOVE = 8;
        public const int PVSEARCH = 9;

        public const int NFUNC = 10;

        public static long[] chamadas = new long[NFUNC];
        public static Stopwatch[] ms = new Stopwatch[NFUNC];

        public static long[] maiorMs = new long[NFUNC];
        public static long[] menorMs = new long[NFUNC];

        public static List<double> evaluate = new List<double>();
        public static List<double> zWSearch = new List<double>();

        public static Stopwatch[] msAux = new Stopwatch[NFUNC]; // usado para localizar o menor e maior tempos

        public static void InitiateBench()
        {
            for (int ix = 0; ix < NFUNC; ix++)
            {
                msAux[ix] = new Stopwatch();
                ms[ix] = new Stopwatch();
                chamadas[ix] = 0;
                maiorMs[ix] = 0;
                menorMs[ix] = long.MaxValue;
            }
        }

        public static void zerar()
        {
            for (int i = 0; i < menorMs.Length; i++) menorMs[i] = long.MaxValue;

            Array.Clear(maiorMs, 0, maiorMs.Length);
            Array.Clear(chamadas, 0, chamadas.Length);
            evaluate.Clear();
            foreach (var w in ms)
            {
                w.Reset();
            }
        }

        public static void MenorMaior(int func)
        {
            if (maiorMs[func] < msAux[func].ElapsedMilliseconds) maiorMs[func] = msAux[func].ElapsedMilliseconds;
            if (menorMs[func] > msAux[func].ElapsedMilliseconds) menorMs[func] = msAux[func].ElapsedMilliseconds;
        }
        public static double Mediana(int func)
        {
            return ((double)maiorMs[func] - (double)menorMs[func]) / 2;
        }

        public static void bench()
        {
            Console.WriteLine("Flipboard: chamadas = {0} - tempos: total = {1} - média = {2} - média MM = {3} - menor = {4} - maior = {5}",
                chamadas[FLIPBOARD], ms[FLIPBOARD].ElapsedMilliseconds,
                (double)ms[FLIPBOARD].ElapsedMilliseconds / (double)chamadas[FLIPBOARD],
                Mediana(FLIPBOARD), menorMs[FLIPBOARD], maiorMs[FLIPBOARD]);

            Console.WriteLine("kingSafe: chamadas = {0} - tempos: total = {1} - média = {2} - média MM = {3} - menor = {4} - maior = {5}",
               chamadas[KINGSAFE], ms[KINGSAFE].ElapsedMilliseconds,
               (double)ms[KINGSAFE].ElapsedMilliseconds / (double)chamadas[KINGSAFE],
               Mediana(KINGSAFE), menorMs[KINGSAFE], maiorMs[KINGSAFE]);

            Console.WriteLine("RateAttack: chamadas = {0} - tempos: total = {1} - média = {2} - média MM = {3} - menor = {4} - maior = {5}",
               chamadas[RATE_ATTACK], ms[RATE_ATTACK].ElapsedMilliseconds,
               (double)ms[RATE_ATTACK].ElapsedMilliseconds / (double)chamadas[RATE_ATTACK],
               Mediana(RATE_ATTACK), menorMs[RATE_ATTACK], maiorMs[RATE_ATTACK]);

            Console.WriteLine("RateMaterial: chamadas = {0} - tempos: total = {1} - média = {2} - média MM = {3} - menor = {4} - maior = {5}",
               chamadas[RATE_MATERIAL], ms[RATE_MATERIAL].ElapsedMilliseconds,
               (double)ms[RATE_MATERIAL].ElapsedMilliseconds / (double)chamadas[RATE_MATERIAL],
               Mediana(RATE_MATERIAL), menorMs[RATE_MATERIAL], maiorMs[RATE_MATERIAL]);

            Console.WriteLine("RateMoveablitly: chamadas = {0} - tempos: total = {1} - média = {2} - média MM = {3} - menor = {4} - maior = {5}",
               chamadas[RATE_MOVEABLITLY], ms[RATE_MOVEABLITLY].ElapsedMilliseconds,
               (double)ms[RATE_MOVEABLITLY].ElapsedMilliseconds / (double)chamadas[RATE_MOVEABLITLY],
               Mediana(RATE_MOVEABLITLY), menorMs[RATE_MOVEABLITLY], maiorMs[RATE_MOVEABLITLY]);

            Console.WriteLine("RatePositional: chamadas = {0} - tempos: total = {1} - média = {2} - média MM = {3} - menor = {4} - maior = {5}",
               chamadas[RATE_POSITIONAL], ms[RATE_POSITIONAL].ElapsedMilliseconds,
               (double)ms[RATE_POSITIONAL].ElapsedMilliseconds / (double)chamadas[RATE_POSITIONAL],
               Mediana(RATE_POSITIONAL), menorMs[RATE_POSITIONAL], maiorMs[RATE_POSITIONAL]);

            Console.WriteLine("Evaluate: chamadas = {0} - tempos: total = {1} - média = {2} - média MM = {3} - menor = {4} - maior = {5}",
               chamadas[EVALUATE], ms[EVALUATE].ElapsedMilliseconds,
               (double)ms[EVALUATE].ElapsedMilliseconds / (double)chamadas[EVALUATE],
               Mediana(EVALUATE), menorMs[EVALUATE], maiorMs[EVALUATE]);

            Console.WriteLine("ZWSearch: chamadas = {0} - tempos: total = {1} - média = {2} - média MM = {3} - menor = {4} - maior = {5}",
               chamadas[ZWSEARCH], ms[ZWSEARCH].ElapsedMilliseconds,
               (double)ms[ZWSEARCH].ElapsedMilliseconds / (double)chamadas[ZWSEARCH],
               Mediana(ZWSEARCH), menorMs[ZWSEARCH], maiorMs[ZWSEARCH]);

            Console.WriteLine("GetFirstLegalMove: chamadas = {0} - tempos: total = {1} - média = {2} - média MM = {3} - menor = {4} - maior = {5}",
               chamadas[GETFIRSTLEGALMOVE], ms[GETFIRSTLEGALMOVE].ElapsedMilliseconds,
               (double)ms[GETFIRSTLEGALMOVE].ElapsedMilliseconds / (double)chamadas[GETFIRSTLEGALMOVE],
               Mediana(GETFIRSTLEGALMOVE), (double)menorMs[GETFIRSTLEGALMOVE], (double)maiorMs[GETFIRSTLEGALMOVE]);

            Console.WriteLine("PvSearch: chamadas = {0} - tempos: total = {1} - média = {2} - média MM = {3} - menor = {4} - maior = {5}",
               chamadas[PVSEARCH], ms[PVSEARCH].ElapsedMilliseconds,
               (double)ms[PVSEARCH].ElapsedMilliseconds / (double)chamadas[PVSEARCH],
               Mediana(PVSEARCH), menorMs[PVSEARCH], maiorMs[PVSEARCH]);

            //evaluate
            var s = new StringBuilder();
            foreach (var t in evaluate)
            {
                s.AppendLine(t.ToString());
            }

            File.WriteAllText("evaluate.txt", s.ToString());

            //zWSearch
            var s1 = new StringBuilder();
            foreach (var t in zWSearch)
            {
                s.AppendLine(t.ToString());
            }

            File.WriteAllText("zWSearch.txt", s.ToString());

        }
    }
}
