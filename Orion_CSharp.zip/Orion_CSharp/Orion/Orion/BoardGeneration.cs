﻿using System;
/*
* PIECE=WHITE/black
* pawn=P/p
* kinght (horse)=N/n
* bishop=B/b
* rook (castle)=R/r
* Queen=Q/q
* King=K/k
*/
namespace Orion
{
    class BoardGeneration
    {

        public static String[,] chessBoardAtual = new String[8, 8];
        public static int kingPositionW;
        public static int kingPositionB;

        public static void initiateStandardChess()
        {
            ulong WP = 0L, WN = 0L, WB = 0L, WR = 0L, WQ = 0L, WK = 0L, BP = 0L, BN = 0L, BB = 0L, BR = 0L, BQ = 0L, BK = 0L;
            String[,] chessBoard =
            {
                {"r","n","b","q","k","b","n","r"},
                {"p","p","p","p","p","p","p","p"},
                {" "," "," "," "," "," "," "," "},
                {" "," "," "," "," "," "," "," "},
                {" "," "," "," "," "," "," "," "},
                {" "," "," "," "," "," "," "," "},
                {"P","P","P","P","P","P","P","P"},
                {"R","N","B","Q","K","B","N","R"}
            };

            arrayToBitboards(chessBoard, WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK);
        }

        public static void initiateChess960()
        {
            ulong WP = 0L, WN = 0L, WB = 0L, WR = 0L, WQ = 0L, WK = 0L, BP = 0L, BN = 0L, BB = 0L, BR = 0L, BQ = 0L, BK = 0L;
            String[,] chessBoard = {
            {" "," "," "," "," "," "," "," "},
            {"p","p","p","p","p","p","p","p"},
            {" "," "," "," "," "," "," "," "},
            {" "," "," "," "," "," "," "," "},
            {" "," "," "," "," "," "," "," "},
            {" "," "," "," "," "," "," "," "},
            {"P","P","P","P","P","P","P","P"},
            {" "," "," "," "," "," "," "," "}};
            // step 1:
            Random randNum = new Random();
            int random1 = ((int)((randNum.Next() * 8)));
            chessBoard[0, random1] = "b";
            chessBoard[7, random1] = "B";
            //step 2:
            int random2 = (int)(randNum.Next() * 8);
            while (random2 % 2 == random1 % 2)
            {
                random2 = (int)(randNum.Next() * 8);
            }
            chessBoard[0, random2] = "b";
            chessBoard[7, random2] = "B";
            //step 3:
            int random3 = (int)(randNum.Next() * 8);
            while (random3 == random1 || random3 == random2)
            {
                random3 = (int)(randNum.Next() * 8);
            }
            chessBoard[0, random3] = "q";
            chessBoard[7, random3] = "Q";
            //step 4:
            int random4a = (int)(randNum.Next() * 5);
            int counter = 0;
            int loop = 0;
            while (counter - 1 < random4a)
            {
                if (" ".Equals(chessBoard[0, loop])) { counter++; }
                loop++;
            }
            chessBoard[0, loop - 1] = "n";
            chessBoard[7, loop - 1] = "N";
            int random4b = (int)(randNum.Next() * 4);
            counter = 0;
            loop = 0;
            while (counter - 1 < random4b)
            {
                if (" ".Equals(chessBoard[0, loop])) { counter++; }
                loop++;
            }
            chessBoard[0, loop - 1] = "n";
            chessBoard[7, loop - 1] = "N";
            //step 5:
            counter = 0;
            while (!" ".Equals(chessBoard[0, counter]))
            {
                counter++;
            }
            chessBoard[0, counter] = "r";
            chessBoard[7, counter] = "R";
            while (!" ".Equals(chessBoard[0, counter]))
            {
                counter++;
            }
            chessBoard[0, counter] = "k";
            chessBoard[7, counter] = "K";
            while (!" ".Equals(chessBoard[0, counter]))
            {
                counter++;
            }
            chessBoard[0, counter] = "r";
            chessBoard[7, counter] = "R";
            arrayToBitboards(chessBoard, WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK);
        }

        public static void importFEN(String fenString)
        {
            //not chess960 compatible
            Orion.WP = 0; Orion.WN = 0; Orion.WB = 0;
            Orion.WR = 0; Orion.WQ = 0; Orion.WK = 0;
            Orion.BP = 0; Orion.BN = 0; Orion.BB = 0;
            Orion.BR = 0; Orion.BQ = 0; Orion.BK = 0;
            Orion.CWK = false; Orion.CWQ = false;
            Orion.CBK = false; Orion.CBQ = false;
            int charIndex = 0;
            int boardIndex = 0;
            while (fenString.ToCharArray()[charIndex] != ' ')
            {
                switch (fenString.ToCharArray()[charIndex++])
                {
                    case 'P':
                        Orion.WP |= ((ulong)1L << boardIndex++);
                        break;
                    case 'p':
                        Orion.BP |= ((ulong)1L << boardIndex++);
                        break;
                    case 'N':
                        Orion.WN |= ((ulong)1L << boardIndex++);
                        break;
                    case 'n':
                        Orion.BN |= ((ulong)1L << boardIndex++);
                        break;
                    case 'B':
                        Orion.WB |= ((ulong)1L << boardIndex++);
                        break;
                    case 'b':
                        Orion.BB |= ((ulong)1L << boardIndex++);
                        break;
                    case 'R':
                        Orion.WR |= ((ulong)1L << boardIndex++);
                        break;
                    case 'r':
                        Orion.BR |= ((ulong)1L << boardIndex++);
                        break;
                    case 'Q':
                        Orion.WQ |= ((ulong)1L << boardIndex++);
                        break;
                    case 'q':
                        Orion.BQ |= ((ulong)1L << boardIndex++);
                        break;
                    case 'K':
                        Orion.WK |= ((ulong)1L << boardIndex++);
                        break;
                    case 'k':
                        Orion.BK |= ((ulong)1L << boardIndex++);
                        break;
                    case '/':
                        break;
                    case '1':
                        boardIndex++;
                        break;
                    case '2':
                        boardIndex += 2;
                        break;
                    case '3':
                        boardIndex += 3;
                        break;
                    case '4':
                        boardIndex += 4;
                        break;
                    case '5':
                        boardIndex += 5;
                        break;
                    case '6':
                        boardIndex += 6;
                        break;
                    case '7':
                        boardIndex += 7;
                        break;
                    case '8':
                        boardIndex += 8;
                        break;
                    default:
                        break;
                }
            }

            Orion.WhiteToMove = (fenString.ToCharArray()[++charIndex] == 'w'); //aqui colocar no cSharp
            charIndex += 2;
            while (fenString.ToCharArray()[charIndex] != ' ')
            {
                switch (fenString.ToCharArray()[charIndex++])
                {
                    case '-':
                        break;
                    case 'K':
                        Orion.CWK = true;
                        break;
                    case 'Q':
                        Orion.CWQ = true;
                        break;
                    case 'k':
                        Orion.CBK = true;
                        break;
                    case 'q':
                        Orion.CBQ = true;
                        break;
                    default:
                        break;
                }
            }
            if (fenString.ToCharArray()[++charIndex] != '-')
            {
                Orion.EP = Moves.FileMasks8[fenString.ToCharArray()[charIndex++] - 'a'];
            }
            //the rest of the fenString is not yet utilized

        }

        public static void arrayToBitboards(String[,] chessBoard, ulong WP, ulong WN, ulong WB, ulong WR, ulong WQ, ulong WK, ulong BP, ulong BN, ulong BB, ulong BR, ulong BQ, ulong BK)
        {
            String Binary;
            for (int i = 0; i < 64; i++)
            {
                Binary = "0000000000000000000000000000000000000000000000000000000000000000";
                Binary = Binary.Substring(i + 1) + "1" + Binary.Substring(0, i);
                switch (chessBoard[i / 8, i % 8])
                {
                    case "P":
                        WP += (ulong)convertStringToBitboard(Binary);
                        break;
                    case "N":
                        WN += (ulong)convertStringToBitboard(Binary);
                        break;
                    case "B":
                        WB += (ulong)convertStringToBitboard(Binary);
                        break;
                    case "R":
                        WR += (ulong)convertStringToBitboard(Binary);
                        break;
                    case "Q":
                        WQ += (ulong)convertStringToBitboard(Binary);
                        break;
                    case "K":
                        WK += (ulong)convertStringToBitboard(Binary);
                        break;
                    case "p":
                        BP += (ulong)convertStringToBitboard(Binary);
                        break;
                    case "n":
                        BN += (ulong)convertStringToBitboard(Binary);
                        break;
                    case "b":
                        BB += (ulong)convertStringToBitboard(Binary);
                        break;
                    case "r":
                        BR += (ulong)convertStringToBitboard(Binary);
                        break;
                    case "q":
                        BQ += (ulong)convertStringToBitboard(Binary);
                        break;
                    case "k":
                        BK += (ulong)convertStringToBitboard(Binary);
                        break;
                }
            }
            drawArray(WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK);
            Orion.WP = WP; Orion.WN = WN; Orion.WB = WB;
            Orion.WR = WR; Orion.WQ = WQ; Orion.WK = WK;
            Orion.BP = BP; Orion.BN = BN; Orion.BB = BB;
            Orion.BR = BR; Orion.BQ = BQ; Orion.BK = BK;
        }

        public static long convertStringToBitboard(String Binary)
        {
            if (Binary.ToCharArray()[0] == '0')
            {//not going to be a negative number
                return Convert.ToInt64(Binary, 2);
            }
            else
            {
                return Convert.ToInt64("1" + Binary.Substring(2), 2) * 2;
            }
        }

        public static void drawArray(ulong WP, ulong WN, ulong WB, ulong WR, ulong WQ, ulong WK, ulong BP, ulong BN, ulong BB, ulong BR, ulong BQ, ulong BK)
        {
            String[,] chessBoard = new String[8, 8];
            for (int i = 0; i < 64; i++)
            {
                chessBoard[i / 8, i % 8] = " ";
            }
            for (int i = 0; i < 64; i++)
            {
                if (((WP >> i) & 1) == 1) { chessBoard[i / 8, i % 8] = "P"; }
                if (((WN >> i) & 1) == 1) { chessBoard[i / 8, i % 8] = "N"; }
                if (((WB >> i) & 1) == 1) { chessBoard[i / 8, i % 8] = "B"; }
                if (((WR >> i) & 1) == 1) { chessBoard[i / 8, i % 8] = "R"; }
                if (((WQ >> i) & 1) == 1) { chessBoard[i / 8, i % 8] = "Q"; }
                if (((WK >> i) & 1) == 1) { chessBoard[i / 8, i % 8] = "K"; }
                if (((BP >> i) & 1) == 1) { chessBoard[i / 8, i % 8] = "p"; }
                if (((BN >> i) & 1) == 1) { chessBoard[i / 8, i % 8] = "n"; }
                if (((BB >> i) & 1) == 1) { chessBoard[i / 8, i % 8] = "b"; }
                if (((BR >> i) & 1) == 1) { chessBoard[i / 8, i % 8] = "r"; }
                if (((BQ >> i) & 1) == 1) { chessBoard[i / 8, i % 8] = "q"; }
                if (((BK >> i) & 1) == 1) { chessBoard[i / 8, i % 8] = "k"; }
            }
            for (int i = 0; i < 8; i++)
            {
                Console.WriteLine();
                for (int j = 0; j < 8; j++)
                    Console.Write(chessBoard[i, j]);
            }
        }

        public static void drawBitboard(long bitBoard)
        {
            const int TOTALCASAS = 64;
            const int TOTALLINHAS = 8;
            const int TOTALCOLUNAS = 8;
            String[,] chessB = new String[8, 8];
            for (int i = 0; i < TOTALCASAS; i++)
            {
                chessB[i / TOTALLINHAS, i % TOTALCOLUNAS] = "";
            }
            for (int i = 0; i < TOTALCASAS; i++)
            {
                if ((LongExtensions.LongShiftRight(bitBoard, i) & 1) == 1)
                {
                    chessB[i / TOTALLINHAS, i % TOTALCOLUNAS] = "1";
                }
                if ("".Equals(chessB[i / TOTALLINHAS, i % TOTALCOLUNAS]))
                {
                    chessB[i / TOTALLINHAS, i % TOTALCOLUNAS] = "0";
                }
            }

        }

        public static void flipBoard()
        {
            Bench.chamadas[Bench.FLIPBOARD]++;

            Bench.ms[Bench.FLIPBOARD].Start();

            Bench.msAux[Bench.FLIPBOARD].Restart();

            String temp;
            for (int i = 0; i < 32; i++)
            {
                int r = i / 8, c = i % 8;
                if (char.IsUpper(chessBoardAtual[r, c].ToCharArray()[0]))
                {
                    temp = chessBoardAtual[r, c].ToLower();
                }
                else
                {
                    temp = chessBoardAtual[r, c].ToUpper();
                }
                if (char.IsUpper(chessBoardAtual[7 - r, 7 - c].ToCharArray()[0]))
                {
                    chessBoardAtual[r, c] = chessBoardAtual[7 - r, 7 - c].ToLower();
                }
                else
                {
                    chessBoardAtual[r, c] = chessBoardAtual[7 - r, 7 - c].ToUpper();
                }
                chessBoardAtual[7 - r, 7 - c] = temp;
            }
            int kingTemp = kingPositionW;
            kingPositionW = 63 - kingPositionB;
            kingPositionB = 63 - kingTemp;

            Bench.ms[Bench.FLIPBOARD].Stop();
            Bench.msAux[Bench.FLIPBOARD].Stop();
            Bench.MenorMaior(Bench.FLIPBOARD);
        }

        public static bool kingSafe()
        {
            Bench.chamadas[Bench.KINGSAFE]++;

            Bench.ms[Bench.KINGSAFE].Start();

            Bench.msAux[Bench.KINGSAFE].Restart();
            //bishop/queen

            int indiceLinha;
            int indiceColuna;
            
            int temp = 1;
            for (int i = -1; i <= 1; i += 2)
            {
                for (int j = -1; j <= 1; j += 2)
                {

                    indiceLinha = kingPositionW / 8 + temp * i;
                    indiceColuna = kingPositionW % 8 + temp * j;

                    while (indiceLinha >= 0 && indiceColuna >= 0 && indiceLinha <= 7 && indiceColuna <= 7)
                    {
                        if (chessBoardAtual[indiceLinha, indiceColuna] == " ")
                        {
                            temp++;
                            indiceLinha = kingPositionW / 8 + temp * i;
                            indiceColuna = kingPositionW % 8 + temp * i;

                            if (!(indiceLinha >= 0 && indiceColuna >= 0) && (indiceLinha <= 7 && indiceColuna <= 7)) break;
                        }
                        else break;
                    }

                    if (indiceLinha >= 0 && indiceColuna >= 0 && indiceLinha <= 7 && indiceColuna <= 7)
                    {
                        if ((chessBoardAtual[indiceLinha, indiceColuna] == "b") ||
                            (chessBoardAtual[indiceLinha, indiceColuna] == "q"))
                        {
                            Bench.ms[Bench.KINGSAFE].Stop();
                            Bench.msAux[Bench.KINGSAFE].Stop();
                            Bench.MenorMaior(Bench.KINGSAFE);
                            return false;
                        }
                    }
                    temp = 1;
                }
            }
            //rook/queen
            for (int i = -1; i <= 1; i += 2)
            {
                indiceLinha = kingPositionW / 8;
                indiceColuna = kingPositionW % 8 + temp * i;

                while ((indiceLinha >= 0 && indiceColuna >= 0) && (indiceLinha <= 7 && indiceColuna <= 7))
                {
                    if (chessBoardAtual[indiceLinha, indiceColuna] == " ")
                    {
                        temp++;
                        indiceColuna = kingPositionW % 8 + temp * i;
                        if (!(indiceColuna >= 0 && indiceColuna <= 7)) break;
                    }
                    else break;
                }

                if ((indiceLinha >= 0 && indiceColuna >= 0) && (indiceLinha <= 7 && indiceColuna <= 7))
                {
                    if (chessBoardAtual[indiceLinha, indiceColuna] == "r" ||
                        chessBoardAtual[indiceLinha, indiceColuna] == "q")
                    {
                        Bench.ms[Bench.KINGSAFE].Stop();
                        Bench.msAux[Bench.KINGSAFE].Stop();
                        Bench.MenorMaior(Bench.KINGSAFE);
                        return false;
                    }
                }

                temp = 1;

                indiceLinha = kingPositionW / 8 + temp * i;
                indiceColuna = kingPositionW % 8;

                while (indiceLinha >= 0 && indiceColuna >= 0 && indiceLinha <= 7 && indiceColuna <= 7)
                {
                    if (chessBoardAtual[indiceLinha, indiceColuna] == " ")
                    {
                        temp++;
                        indiceLinha = kingPositionW / 8 + temp * i;

                        if (!(indiceLinha >= 0 && indiceLinha <= 7)) break;
                    }
                    else break;
                }

                if (indiceLinha >= 0 && indiceColuna >= 0 && indiceLinha <= 7 && indiceColuna <= 7)
                {
                    if (chessBoardAtual[indiceLinha, indiceColuna] == "r" ||
                        chessBoardAtual[indiceLinha, indiceColuna] == "q")
                    {
                        Bench.ms[Bench.KINGSAFE].Stop();
                        Bench.msAux[Bench.KINGSAFE].Stop();
                        Bench.MenorMaior(Bench.KINGSAFE);
                        return false;
                    }
                }

                temp = 1;
            }
            //knight
            for (int i = -1; i <= 1; i += 2)
            {
                for (int j = -1; j <= 1; j += 2)
                {
                    indiceLinha = kingPositionW / 8 + i;
                    indiceColuna = kingPositionW % 8 + j * 2;

                    if ((indiceLinha >= 0 && indiceColuna >= 0) && (indiceLinha <= 7 && indiceColuna <= 7))
                    {
                        if (chessBoardAtual[indiceLinha, indiceColuna] == "k")
                        {
                            Bench.ms[Bench.KINGSAFE].Stop();
                            Bench.msAux[Bench.KINGSAFE].Stop();
                            Bench.MenorMaior(Bench.KINGSAFE);
                            return false;
                        }
                    }

                    indiceLinha = kingPositionW / 8 + i * 2;
                    indiceColuna = kingPositionW % 8 + j;

                    if (indiceLinha >= 0 && indiceColuna >= 0 && indiceLinha <= 7 && indiceColuna <= 7)
                    {
                        if (chessBoardAtual[indiceLinha, indiceColuna] == "k")
                        {
                            Bench.ms[Bench.KINGSAFE].Stop();
                            Bench.msAux[Bench.KINGSAFE].Stop();
                            Bench.MenorMaior(Bench.KINGSAFE);
                            return false;
                        }
                    }
                }
            }
            //pawn
            if (kingPositionW >= 16)
            {
                indiceLinha = kingPositionW / 8 - 1;
                indiceColuna = kingPositionW % 8 - 1;

                if (indiceLinha >= 0 && indiceColuna >= 0 && indiceLinha <= 7 && indiceColuna <= 7)
                {
                    if (chessBoardAtual[indiceLinha, indiceColuna] == "p")
                    {
                        Bench.ms[Bench.KINGSAFE].Stop();
                        Bench.msAux[Bench.KINGSAFE].Stop();
                        Bench.MenorMaior(Bench.KINGSAFE);
                        return false;
                    }

                    if (chessBoardAtual[indiceLinha - 1, indiceColuna + 1] == "p")
                    {
                        Bench.ms[Bench.KINGSAFE].Stop();
                        Bench.msAux[Bench.KINGSAFE].Stop();
                        Bench.MenorMaior(Bench.KINGSAFE);
                        return false;
                    }
                }

            }
            //king
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (i != 0 || j != 0)
                    {
                        indiceLinha = kingPositionW / 8 + i;
                        indiceColuna = kingPositionW % 8 + j;

                        if (indiceLinha >= 0 && indiceColuna >= 0 && indiceLinha <= 7 && indiceColuna <= 7)
                        {
                            if (chessBoardAtual[indiceLinha, indiceColuna] == "a")
                            {
                                Bench.ms[Bench.KINGSAFE].Stop();
                                Bench.msAux[Bench.KINGSAFE].Stop();
                                Bench.MenorMaior(Bench.KINGSAFE);
                                return false;
                            }
                        }

                    }
                }
            }

            Bench.ms[Bench.KINGSAFE].Stop();
            Bench.msAux[Bench.KINGSAFE].Stop();
            Bench.MenorMaior(Bench.KINGSAFE);

            return true;
        }

        //retorna uma cópia do array no formato algebrico

        public static void getChessboardArray(ulong WP, ulong WN, ulong WB, ulong WR, ulong WQ, ulong WK, ulong BP, ulong BN, ulong BB, ulong BR, ulong BQ, ulong BK)
        {

            for (int i = 0; i < 64; i++)
            {
                chessBoardAtual[i / 8, i % 8] = " ";
            }
            for (int i = 0; i < 64; i++)
            {
                if (((WP >> i) & 1) == 1) { chessBoardAtual[i / 8, i % 8] = "P"; }
                if (((WN >> i) & 1) == 1) { chessBoardAtual[i / 8, i % 8] = "N"; }
                if (((WB >> i) & 1) == 1) { chessBoardAtual[i / 8, i % 8] = "B"; }
                if (((WR >> i) & 1) == 1) { chessBoardAtual[i / 8, i % 8] = "R"; }
                if (((WQ >> i) & 1) == 1) { chessBoardAtual[i / 8, i % 8] = "Q"; }
                if (((WK >> i) & 1) == 1) { chessBoardAtual[i / 8, i % 8] = "K"; }
                if (((BP >> i) & 1) == 1) { chessBoardAtual[i / 8, i % 8] = "p"; }
                if (((BN >> i) & 1) == 1) { chessBoardAtual[i / 8, i % 8] = "n"; }
                if (((BB >> i) & 1) == 1) { chessBoardAtual[i / 8, i % 8] = "b"; }
                if (((BR >> i) & 1) == 1) { chessBoardAtual[i / 8, i % 8] = "r"; }
                if (((BQ >> i) & 1) == 1) { chessBoardAtual[i / 8, i % 8] = "q"; }
                if (((BK >> i) & 1) == 1) { chessBoardAtual[i / 8, i % 8] = "k"; }
            }
        }

    }
}