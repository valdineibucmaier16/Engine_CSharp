﻿using System;
using System.Diagnostics;

namespace Orion
{
    public class Moves
    {

        static ulong FILE_A = 72340172838076673L;
        static long FILE_h = -9187201950435737472L;
        static ulong FILE_H = (ulong)FILE_h;
        static ulong FILE_AB = 217020518514230019L;
        static long FILE_Gh = -4557430888798830400L;
        static ulong FILE_GH = (ulong)FILE_Gh;
        static long RANK_um = -72057594037927936L;
        static ulong RANK_1 = (ulong)RANK_um;
        static ulong RANK_4 = 1095216660480L;
        static ulong RANK_5 = 4278190080L;
        static ulong RANK_8 = 255L;
        static ulong CENTRE = 103481868288L;
        static ulong EXTENDED_CENTRE = 66229406269440L;
        static long KING_SIDE = -1085102592571150096L;
        static ulong QUEEN_SIDE = 1085102592571150095L;
        static ulong KING_SPAN = 460039L;
        static ulong KNIGHT_SPAN = 43234889994L;
        static ulong NOT_MY_PIECES;
        static ulong MY_PIECES;
        public static ulong OCCUPIED;
        static ulong EMPTY;
        public static int[] CASTLE_ROOKS = new int[] { 63, 56, 7, 0 };
        public static ulong[] RankMasks8 = new ulong[]/*from rank1 to rank8*/
        {
        0xFFL, 0xFF00L, 0xFF0000L, 0xFF000000L, 0xFF00000000L, 0xFF0000000000L, 0xFF000000000000L, 0xFF00000000000000L
        };
        public static ulong[] FileMasks8 = new ulong[]/*from fileA to FileH*/
        {
        0x101010101010101L, 0x202020202020202L, 0x404040404040404L, 0x808080808080808L,
        0x1010101010101010L, 0x2020202020202020L, 0x4040404040404040L, 0x8080808080808080L
        };
        static ulong[] DiagonalMasks8 = new ulong[]/*from top left to bottom right*/
        {
        0x1L, 0x102L, 0x10204L, 0x1020408L, 0x102040810L, 0x10204081020L, 0x1020408102040L,
        0x102040810204080L, 0x204081020408000L, 0x408102040800000L, 0x810204080000000L,
        0x1020408000000000L, 0x2040800000000000L, 0x4080000000000000L, 0x8000000000000000L
        };
        static ulong[] AntiDiagonalMasks8 = new ulong[]/*from top right to bottom left*/
        {
        0x80L, 0x8040L, 0x804020L, 0x80402010L, 0x8040201008L, 0x804020100804L, 0x80402010080402L,
        0x8040201008040201L, 0x4020100804020100L, 0x2010080402010000L, 0x1008040201000000L,
        0x804020100000000L, 0x402010000000000L, 0x201000000000000L, 0x100000000000000L
        };
        static ulong HAndVMoves(int s)
        {
            //REMINDER: requires OCCUPIED to be up to date
            ulong binaryS = (ulong)1L << s;
            ulong possibilitiesHorizontal = (OCCUPIED - 2 * binaryS) ^ LongExtensions.Reverse(LongExtensions.Reverse(OCCUPIED) - 2 * LongExtensions.Reverse(binaryS));
            ulong possibilitiesVertical = ((OCCUPIED & FileMasks8[s % 8]) - (2 * binaryS)) ^ LongExtensions.Reverse(LongExtensions.Reverse(OCCUPIED & FileMasks8[s % 8]) - (2 * LongExtensions.Reverse(binaryS)));
            return (possibilitiesHorizontal & RankMasks8[s / 8]) | (possibilitiesVertical & FileMasks8[s % 8]);
        }
        static ulong DAndAntiDMoves(int s)
        {
            //REMINDER: requires OCCUPIED to be up to date
            ulong binaryS = (ulong)1L << s;
            ulong possibilitiesDiagonal = ((OCCUPIED & DiagonalMasks8[(s / 8) + (s % 8)]) - (2 * binaryS)) ^ LongExtensions.Reverse(LongExtensions.Reverse(OCCUPIED & DiagonalMasks8[(s / 8) + (s % 8)]) - (2 * LongExtensions.Reverse(binaryS)));
            ulong possibilitiesAntiDiagonal = ((OCCUPIED & AntiDiagonalMasks8[(s / 8) + 7 - (s % 8)]) - (2 * binaryS)) ^ LongExtensions.Reverse(LongExtensions.Reverse(OCCUPIED & AntiDiagonalMasks8[(s / 8) + 7 - (s % 8)]) - (2 * LongExtensions.Reverse(binaryS)));
            return (possibilitiesDiagonal & DiagonalMasks8[(s / 8) + (s % 8)]) | (possibilitiesAntiDiagonal & AntiDiagonalMasks8[(s / 8) + 7 - (s % 8)]);
        }
        public static ulong makeMove(ulong board, String move, char type)
        {
            if (char.IsDigit(move.ToCharArray()[3]))
            {//'regular' move
                int start = Convert.ToInt32((char.GetNumericValue(move.ToCharArray()[0]) * 8) + (char.GetNumericValue(move.ToCharArray()[1])));
                int end = Convert.ToInt32((char.GetNumericValue(move.ToCharArray()[2]) * 8) + (char.GetNumericValue(move.ToCharArray()[3])));
                if (((board >> start) & 1) == 1) { board &= ~((ulong)1L << start); board |= ((ulong)1L << end); } else { board &= ~((ulong)1L << end); }
            }
            else if (move.ToCharArray()[3] == 'P')
            {//pawn promotion
                int start, end;
                if (char.IsUpper(move.ToCharArray()[2]))
                {
                    start = LongExtensions.NumberOfTrailingZeros(FileMasks8[move.ToCharArray()[0] - '0'] & RankMasks8[1]);
                    end = LongExtensions.NumberOfTrailingZeros(FileMasks8[move.ToCharArray()[1] - '0'] & RankMasks8[0]);
                }
                else
                {
                    start = LongExtensions.NumberOfTrailingZeros(FileMasks8[move.ToCharArray()[0] - '0'] & RankMasks8[6]);
                    end = LongExtensions.NumberOfTrailingZeros(FileMasks8[move.ToCharArray()[1] - '0'] & RankMasks8[7]);
                }
                if (type == move.ToCharArray()[2]) { board |= ((ulong)1L << end); } else { board &= ~((ulong)1L << start); board &= ~((ulong)1L << end); }
            }
            else if (move.ToCharArray()[3] == 'E')
            {//en passant
                int start, end;
                if (move.ToCharArray()[2] == 'W')
                {
                    start = LongExtensions.NumberOfTrailingZeros(FileMasks8[move.ToCharArray()[0] - '0'] & RankMasks8[3]);
                    end = LongExtensions.NumberOfTrailingZeros(FileMasks8[move.ToCharArray()[1] - '0'] & RankMasks8[2]);
                    board &= ~(FileMasks8[move.ToCharArray()[1] - '0'] & RankMasks8[3]);
                }
                else
                {
                    start = LongExtensions.NumberOfTrailingZeros(FileMasks8[move.ToCharArray()[0] - '0'] & RankMasks8[4]);
                    end = LongExtensions.NumberOfTrailingZeros(FileMasks8[move.ToCharArray()[1] - '0'] & RankMasks8[5]);
                    board &= ~(FileMasks8[move.ToCharArray()[1] - '0'] & RankMasks8[4]);
                }
                if (((board >> start) & 1) == 1) { board &= ~((ulong)1L << start); board |= ((ulong)1L << end); }
            }
            else
            {
                Console.WriteLine("ERROR: Invalid move type");
            }
            return (ulong)board;
        }
        public static ulong makeMoveCastle(ulong rookBoard, ulong kingBoard, String move, char type)
        {
            int start = (int)((char.GetNumericValue(move.ToCharArray()[0]) * 8) + (char.GetNumericValue(move.ToCharArray()[1])));
            if ((((kingBoard >> start) & 1) == 1) && (("0402".Equals(move)) || ("0406".Equals(move)) || ("7472".Equals(move)) || ("7476".Equals(move))))

            {//'regular' move
                if (type == 'R')
                {

                    switch (move)
                    {
                        case "7472":
                            rookBoard &= ~((ulong)1L << CASTLE_ROOKS[1]); rookBoard |= ((ulong)1L << (CASTLE_ROOKS[1] + 3));
                            break;
                        case "7476":
                            rookBoard &= ~((ulong)1L << CASTLE_ROOKS[0]); rookBoard |= ((ulong)1L << (CASTLE_ROOKS[0] - 2));
                            break;
                    }
                }
                else
                {
                    switch (move)
                    {
                        case "0402":
                            rookBoard &= ~((ulong)1L << CASTLE_ROOKS[3]); rookBoard |= ((ulong)1L << (CASTLE_ROOKS[3] + 3));
                            break;
                        case "0406":
                            rookBoard &= ~((ulong)1L << CASTLE_ROOKS[2]); rookBoard |= ((ulong)1L << (CASTLE_ROOKS[2] - 2));
                            break;
                    }
                }
            }
            return (ulong)rookBoard;
        }
        public static ulong makeMoveEP(ulong board, String move)
        {
            if (char.IsDigit(move.ToCharArray()[3]))
            {
                int start = (int)((char.GetNumericValue(move.ToCharArray()[0]) * 8) + (char.GetNumericValue(move.ToCharArray()[1])));
                if ((Math.Abs(move.ToCharArray()[0] - move.ToCharArray()[2]) == 2) && (((board >> start) & 1) == 1))

                {//pawn double push

                    {
                        return ((FileMasks8[move.ToCharArray()[1] - '0']));
                    }
                }
            }
            return 0;
        }
        public static String possibleMovesW(ulong WP, ulong WN, ulong WB, ulong WR, ulong WQ, ulong WK, ulong BP, ulong BN, ulong BB, ulong BR, ulong BQ, ulong BK, ulong EP, bool CWK, bool CWQ, bool CBK, bool CBQ)
        {
            NOT_MY_PIECES = ~(WP | WN | WB | WR | WQ | WK | BK);//added BK to avoid illegal capture
            MY_PIECES = WP | WN | WB | WR | WQ;//omitted WK to avoid illegal capture
            OCCUPIED = WP | WN | WB | WR | WQ | WK | BP | BN | BB | BR | BQ | BK;

            EMPTY = ~OCCUPIED;

            String list = possibleWP(WP, BP, EP) +
                    possibleN(OCCUPIED, WN) +
                    possibleB(OCCUPIED, WB) +
                    possibleR(OCCUPIED, WR) +
                    possibleQ(OCCUPIED, WQ) +
                    possibleK(OCCUPIED, WK) +
                    possibleCW(WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK, CWK, CWQ);
            return list;
        }
        public static String possibleMovesB(ulong WP, ulong WN, ulong WB, ulong WR, ulong WQ, ulong WK, ulong BP, ulong BN, ulong BB, ulong BR, ulong BQ, ulong BK, ulong EP, bool CWK, bool CWQ, bool CBK, bool CBQ)
        {
            NOT_MY_PIECES = ~(BP | BN | BB | BR | BQ | BK | WK);//added WK to avoid illegal capture
            MY_PIECES = BP | BN | BB | BR | BQ;//omitted BK to avoid illegal capture
            OCCUPIED = WP | WN | WB | WR | WQ | WK | BP | BN | BB | BR | BQ | BK;
            EMPTY = ~OCCUPIED;
            String list = possibleBP(BP, WP, EP) +
                    possibleN(OCCUPIED, BN) +
                    possibleB(OCCUPIED, BB) +
                    possibleR(OCCUPIED, BR) +
                    possibleQ(OCCUPIED, BQ) +
                    possibleK(OCCUPIED, BK) +
                    possibleCB(WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK, CBK, CBQ);
            return list;
        }
        public static String possibleWP(ulong WP, ulong BP, ulong EP)
        {
            String list = "";
            //x1,y1,x2,y2
            ulong PAWN_MOVES = (WP >> 7) & NOT_MY_PIECES & OCCUPIED & ~RANK_8 & ~FILE_A;//capture right
            ulong possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);

            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index / 8 + 1) + (index % 8 - 1) + (index / 8) + (index % 8);
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            PAWN_MOVES = (WP >> 9) & NOT_MY_PIECES & OCCUPIED & ~RANK_8 & ~FILE_H;//capture left
            possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index / 8 + 1) + (index % 8 + 1) + (index / 8) + (index % 8);
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            PAWN_MOVES = (WP >> 8) & EMPTY & ~RANK_8;//move 1 forward
            possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index / 8 + 1) + (index % 8) + (index / 8) + (index % 8);
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            PAWN_MOVES = (WP >> 16) & EMPTY & (EMPTY >> 8) & RANK_4;//move 2 forward
            possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index / 8 + 2) + (index % 8) + (index / 8) + (index % 8);
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            //y1,y2,Promotion Type,"P"
            PAWN_MOVES = (WP >> 7) & NOT_MY_PIECES & OCCUPIED & RANK_8 & ~FILE_A;//pawn promotion by capture right
            possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index % 8 - 1) + (index % 8) + "QP" + (index % 8 - 1) + (index % 8) + "RP" + (index % 8 - 1) + (index % 8) + "BP" + (index % 8 - 1) + (index % 8) + "NP";
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            PAWN_MOVES = (WP >> 9) & NOT_MY_PIECES & OCCUPIED & RANK_8 & ~FILE_H;//pawn promotion by capture left
            possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index % 8 + 1) + (index % 8) + "QP" + (index % 8 + 1) + (index % 8) + "RP" + (index % 8 + 1) + (index % 8) + "BP" + (index % 8 + 1) + (index % 8) + "NP";
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            PAWN_MOVES = (WP >> 8) & EMPTY & RANK_8;//pawn promotion by move 1 forward
            possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index % 8) + (index % 8) + "QP" + (index % 8) + (index % 8) + "RP" + (index % 8) + (index % 8) + "BP" + (index % 8) + (index % 8) + "NP";
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            //y1,y2,"WE"
            //en passant right
            possibility = (WP << 1) & BP & RANK_5 & ~FILE_A & EP;//shows piece to remove, not the destination
            if (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index % 8 - 1) + (index % 8) + "WE";
            }
            //en passant left

            possibility = (WP >> 1) & BP & RANK_5 & ~FILE_H & EP;//shows piece to remove, not the destination
            if (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index % 8 + 1) + (index % 8) + "WE";
            }
            return list;
        }
        public static String possibleBP(ulong BP, ulong WP, ulong EP)
        {
            String list = "";
            //x1,y1,x2,y2
            ulong PAWN_MOVES = (BP << 7) & NOT_MY_PIECES & OCCUPIED & ~RANK_1 & ~FILE_H;//capture right
            ulong possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index / 8 - 1) + (index % 8 + 1) + (index / 8) + (index % 8);
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            PAWN_MOVES = (BP << 9) & NOT_MY_PIECES & OCCUPIED & ~RANK_1 & ~FILE_A;//capture left
            possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index / 8 - 1) + (index % 8 - 1) + (index / 8) + (index % 8);
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            PAWN_MOVES = (BP << 8) & EMPTY & ~RANK_1;//move 1 forward
            possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index / 8 - 1) + (index % 8) + (index / 8) + (index % 8);
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            PAWN_MOVES = (BP << 16) & EMPTY & (EMPTY << 8) & RANK_5;//move 2 forward
            possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index / 8 - 2) + (index % 8) + (index / 8) + (index % 8);
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            //y1,y2,Promotion Type,"P"
            PAWN_MOVES = (BP << 7) & NOT_MY_PIECES & OCCUPIED & RANK_1 & ~FILE_H;//pawn promotion by capture right
            possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index % 8 + 1) + (index % 8) + "qP" + (index % 8 + 1) + (index % 8) + "rP" + (index % 8 + 1) + (index % 8) + "bP" + (index % 8 + 1) + (index % 8) + "nP";
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            PAWN_MOVES = (BP << 9) & NOT_MY_PIECES & OCCUPIED & RANK_1 & ~FILE_A;//pawn promotion by capture left
            possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index % 8 - 1) + (index % 8) + "qP" + (index % 8 - 1) + (index % 8) + "rP" + (index % 8 - 1) + (index % 8) + "bP" + (index % 8 - 1) + (index % 8) + "nP";
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            PAWN_MOVES = (BP << 8) & EMPTY & RANK_1;//pawn promotion by move 1 forward
            possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            while (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index % 8) + (index % 8) + "qP" + (index % 8) + (index % 8) + "rP" + (index % 8) + (index % 8) + "bP" + (index % 8) + (index % 8) + "nP";
                PAWN_MOVES &= ~possibility;
                possibility = PAWN_MOVES & ~(PAWN_MOVES - 1);
            }
            //y1,y2,"BE"
            //en passant right
            possibility = (BP >> 1) & WP & RANK_4 & ~FILE_H & EP;//shows piece to remove, not the destination
            if (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index % 8 + 1) + (index % 8) + "BE";
            }
            //en passant left
            possibility = (BP << 1) & WP & RANK_4 & ~FILE_A & EP;//shows piece to remove, not the destination
            if (possibility != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(possibility);
                list += "" + (index % 8 - 1) + (index % 8) + "BE";
            }
            return list;
        }
        public static String possibleN(ulong OCCUPIED, ulong N)
        {
            String list = "";
            ulong i = N & ~(N - 1);
            ulong possibility;
            while (i != 0)
            {
                int iLocation = LongExtensions.NumberOfTrailingZeros(i);
                if (iLocation > 18)
                {
                    possibility = KNIGHT_SPAN << (iLocation - 18);
                }
                else
                {
                    possibility = KNIGHT_SPAN >> (18 - iLocation);
                }
                if (iLocation % 8 < 4)
                {
                    possibility &= ~FILE_GH & NOT_MY_PIECES;
                }
                else
                {
                    possibility &= ~FILE_AB & NOT_MY_PIECES;
                }
                ulong j = possibility & ~(possibility - 1);
                while (j != 0)
                {
                    int index = LongExtensions.NumberOfTrailingZeros(j);
                    list += "" + (iLocation / 8) + (iLocation % 8) + (index / 8) + (index % 8);
                    possibility &= ~j;
                    j = possibility & ~(possibility - 1);
                }
                N &= ~i;
                i = N & ~(N - 1);
            }
            return list;
        }
        public static String possibleB(ulong OCCUPIED, ulong B)
        {
            String list = "";
            ulong i = B & ~(B - 1);
            ulong possibility;
            while (i != 0)
            {
                int iLocation = LongExtensions.NumberOfTrailingZeros(i);
                possibility = DAndAntiDMoves(iLocation) & NOT_MY_PIECES;
                ulong j = possibility & ~(possibility - 1);
                while (j != 0)
                {
                    int index = LongExtensions.NumberOfTrailingZeros(j);
                    list += "" + (iLocation / 8) + (iLocation % 8) + (index / 8) + (index % 8);
                    possibility &= ~j;
                    j = possibility & ~(possibility - 1);
                }
                B &= ~i;
                i = B & ~(B - 1);
            }
            return list;
        }
        public static String possibleR(ulong OCCUPIED, ulong R)
        {
            String list = "";
            ulong i = R & ~(R - 1);
            ulong possibility;
            while (i != 0)
            {
                int iLocation = LongExtensions.NumberOfTrailingZeros(i);
                possibility = HAndVMoves(iLocation) & NOT_MY_PIECES;
                ulong j = possibility & ~(possibility - 1);
                while (j != 0)
                {
                    int index = LongExtensions.NumberOfTrailingZeros(j);
                    list += "" + (iLocation / 8) + (iLocation % 8) + (index / 8) + (index % 8);
                    possibility &= ~j;
                    j = possibility & ~(possibility - 1);
                }
                R &= ~i;
                i = R & ~(R - 1);
            }
            return list;
        }
        public static String possibleQ(ulong OCCUPIED, ulong Q)
        {
            String list = "";
            ulong i = Q & ~(Q - 1);
            ulong possibility;
            while (i != 0)
            {
                int iLocation = LongExtensions.NumberOfTrailingZeros(i);
                possibility = (HAndVMoves(iLocation) | DAndAntiDMoves(iLocation)) & NOT_MY_PIECES;
                ulong j = possibility & ~(possibility - 1);
                while (j != 0)
                {
                    int index = LongExtensions.NumberOfTrailingZeros(j);
                    list += "" + (iLocation / 8) + (iLocation % 8) + (index / 8) + (index % 8);
                    possibility &= ~j;
                    j = possibility & ~(possibility - 1);
                }
                Q &= ~i;
                i = Q & ~(Q - 1);
            }
            return list;
        }
        public static String possibleK(ulong OCCUPIED, ulong K)
        {
            String list = "";
            ulong possibility;
            int iLocation = LongExtensions.NumberOfTrailingZeros(K);
            if (iLocation > 9)
            {
                possibility = KING_SPAN << (iLocation - 9);
            }
            else
            {
                possibility = KING_SPAN >> (9 - iLocation);
            }
            if (iLocation % 8 < 4)
            {
                possibility &= ~FILE_GH & NOT_MY_PIECES;
            }
            else
            {
                possibility &= ~FILE_AB & NOT_MY_PIECES;
            }
            ulong j = possibility & ~(possibility - 1);
            while (j != 0)
            {
                int index = LongExtensions.NumberOfTrailingZeros(j);
                list += "" + (iLocation / 8) + (iLocation % 8) + (index / 8) + (index % 8);
                possibility &= ~j;
                j = possibility & ~(possibility - 1);
            }
            return list;
        }
        public static String possibleCW(ulong WP, ulong WN, ulong WB, ulong WR, ulong WQ, ulong WK, ulong BP, ulong BN, ulong BB, ulong BR, ulong BQ, ulong BK, bool CWK, bool CWQ)
        {
            String list = "";
            ulong dangerous = unsafeForWhite(WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK);
            if ((dangerous & WK) == 0)
            {
                if (CWK && ((((ulong)1L << CASTLE_ROOKS[0]) & WR) != 0))
                {
                    if (((OCCUPIED | dangerous) & ((1L << 61) | (1L << 62))) == 0)
                    {
                        list += "7476";
                    }
                }
                if (CWQ && ((((ulong)1L << CASTLE_ROOKS[1]) & WR) != 0))
                {
                    if (((OCCUPIED | (dangerous & ~((ulong)1L << 57))) & ((1L << 57) | (1L << 58) | (1L << 59))) == 0)
                    {
                        list += "7472";
                    }
                }
            }
            return list;
        }
        public static String possibleCB(ulong WP, ulong WN, ulong WB, ulong WR, ulong WQ, ulong WK, ulong BP, ulong BN, ulong BB, ulong BR, ulong BQ, ulong BK, bool CBK, bool CBQ)
        {
            String list = "";
            ulong dangerous = unsafeForBlack(WP, WN, WB, WR, WQ, WK, BP, BN, BB, BR, BQ, BK);
            if ((dangerous & BK) == 0)
            {
                if (CBK && ((((ulong)1L << CASTLE_ROOKS[2]) & BR) != 0))
                {
                    if (((OCCUPIED | dangerous) & ((1L << 5) | (1L << 6))) == 0)
                    {
                        list += "0406";
                    }
                }
                if (CBQ && ((((ulong)1L << CASTLE_ROOKS[3]) & BR) != 0))
                {
                    if (((OCCUPIED | (dangerous & ~((ulong)1L << 1))) & ((1L << 1) | (1L << 2) | (1L << 3))) == 0)
                    {
                        list += "0402";
                    }
                }
            }
            return list;
        }
        public static ulong unsafeForBlack(ulong WP, ulong WN, ulong WB, ulong WR, ulong WQ, ulong WK, ulong BP, ulong BN, ulong BB, ulong BR, ulong BQ, ulong BK)
        {
            ulong dangerous; //dangerous palavra reservada em C# e não no Java, alterada aqui para dangerous
            OCCUPIED = WP | WN | WB | WR | WQ | WK | BP | BN | BB | BR | BQ | BK;
            //pawn
            dangerous = ((WP >> 7) & ~FILE_A);//pawn capture right
            dangerous |= ((WP >> 9) & ~FILE_H);//pawn capture left
            ulong possibility;
            //knight
            ulong i = WN & ~(WN - 1);

            int iLocation;
            while (i != 0)
            {
                iLocation = LongExtensions.NumberOfTrailingZeros(i);
                if (iLocation > 18)
                {
                    possibility = KNIGHT_SPAN << (iLocation - 18);
                }
                else
                {
                    possibility = KNIGHT_SPAN >> (18 - iLocation);
                }
                if (iLocation % 8 < 4)
                {
                    possibility &= ~FILE_GH;
                }
                else
                {
                    possibility &= ~FILE_AB;
                }
                dangerous |= possibility;
                WN &= ~i;
                i = WN & ~(WN - 1);
            }
            //bishop/queen
            ulong QB = WQ | WB;
            i = QB & ~(QB - 1);
            while (i != 0)
            {
                iLocation = LongExtensions.NumberOfTrailingZeros(i);
                possibility = DAndAntiDMoves(iLocation);
                dangerous |= possibility;
                QB &= ~i;
                i = QB & ~(QB - 1);
            }
            //rook/queen
            ulong QR = WQ | WR;
            i = QR & ~(QR - 1);
            while (i != 0)
            {
                iLocation = LongExtensions.NumberOfTrailingZeros(i);
                possibility = HAndVMoves(iLocation);
                dangerous |= possibility;
                QR &= ~i;
                i = QR & ~(QR - 1);
            }
            //king
            iLocation = LongExtensions.NumberOfTrailingZeros(WK);
            if (iLocation > 9)
            {
                possibility = KING_SPAN << (iLocation - 9);
            }
            else
            {
                possibility = KING_SPAN >> (9 - iLocation);
            }
            if (iLocation % 8 < 4)
            {
                possibility &= ~FILE_GH;
            }
            else
            {
                possibility &= ~FILE_AB;
            }
            dangerous |= possibility;
            return dangerous;
        }
        public static ulong unsafeForWhite(ulong WP, ulong WN, ulong WB, ulong WR, ulong WQ, ulong WK, ulong BP, ulong BN, ulong BB, ulong BR, ulong BQ, ulong BK)
        {
            ulong dangerous;
            OCCUPIED = WP | WN | WB | WR | WQ | WK | BP | BN | BB | BR | BQ | BK;
            //pawn
            dangerous = ((BP << 7) & ~FILE_H);//pawn capture right
            dangerous |= ((BP << 9) & ~FILE_A);//pawn capture left
            ulong possibility;
            //knight
            ulong i = BN & ~(BN - 1);
            int iLocation;
            while (i != 0)
            {
                iLocation = LongExtensions.NumberOfTrailingZeros(i);
                if (iLocation > 18)
                {
                    possibility = KNIGHT_SPAN << (iLocation - 18);
                }
                else
                {
                    possibility = KNIGHT_SPAN >> (18 - iLocation);
                }
                if (iLocation % 8 < 4)
                {
                    possibility &= ~FILE_GH;
                }
                else
                {
                    possibility &= ~FILE_AB;
                }
                dangerous |= possibility;
                BN &= ~i;
                i = BN & ~(BN - 1);
            }
            //bishop/queen
            ulong QB = BQ | BB;
            i = QB & ~(QB - 1);
            while (i != 0)
            {
                iLocation = LongExtensions.NumberOfTrailingZeros(i);
                possibility = DAndAntiDMoves(iLocation);
                dangerous |= possibility;
                QB &= ~i;
                i = QB & ~(QB - 1);
            }
            //rook/queen
            ulong QR = BQ | BR;
            i = QR & ~(QR - 1);
            while (i != 0)
            {
                iLocation = LongExtensions.NumberOfTrailingZeros(i);
                possibility = HAndVMoves(iLocation);
                dangerous |= possibility;
                QR &= ~i;
                i = QR & ~(QR - 1);
            }
            //king
            iLocation = LongExtensions.NumberOfTrailingZeros(BK);
            if (iLocation > 9)
            {
                possibility = KING_SPAN << (iLocation - 9);
            }
            else
            {
                possibility = KING_SPAN >> (9 - iLocation);
            }
            if (iLocation % 8 < 4)
            {
                possibility &= ~FILE_GH;
            }
            else
            {
                possibility &= ~FILE_AB;
            }
            dangerous |= possibility;
            return dangerous;

        }
        public static void drawBitboard(long bitBoard)
        {
            String[,] chessBoard = new String[8, 8];
            for (int i = 0; i < 64; i++)
            {
                chessBoard[i / 8, i % 8] = "";
            }
            for (int i = 0; i < 64; i++)
            {
                if (((LongExtensions.LongShiftRight(bitBoard, i)) & 1) == 1) { chessBoard[i / 8, i % 8] = "P"; }
                if ("".Equals(chessBoard[i / 8, i % 8])) { chessBoard[i / 8, i % 8] = " "; }
            }

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 8; j++)
                    Console.WriteLine(chessBoard[i, j]);
            }
        }
        public static void timeExperiment(long WP)
        {
            int loopLength = 1000;
            var startTime = Stopwatch.StartNew();
            tEMethodA(loopLength, WP);
            startTime.Stop();
            Console.WriteLine("That took " + startTime.ElapsedMilliseconds + " milliseconds for the first method");
            startTime = Stopwatch.StartNew();
            tEMethodB(loopLength, WP);
            startTime.Stop();
            Console.WriteLine("That took " + startTime.ElapsedMilliseconds + " milliseconds for the second method");
        }
        public static void tEMethodA(int loopLength, long WP)
        {
            for (int loop = 0; loop < loopLength; loop++)
            {

            }
        }
        public static void tEMethodB(int loopLength, long WP)
        {
            for (int loop = 0; loop < loopLength; loop++)
            {

            }
        }

    }
}
