﻿

namespace Orion
{
    public class Rating
    {

        static int[,] pawnBoard ={//attribute to http://chessprogramming.wikispaces.com/Simplified+evaluation+function
        { 0,  0,  0,  0,  0,  0,  0,  0},
        {50, 50, 50, 50, 50, 50, 50, 50},
        {10, 10, 20, 30, 30, 20, 10, 10},
        { 5,  5, 10, 25, 25, 10,  5,  5},
        { 0,  0,  0, 20, 20,  0,  0,  0},
        { 5, -5,-10,  0,  0,-10, -5,  5},
        { 5, 10, 10,-20,-20, 10, 10,  5},
        { 0,  0,  0,  0,  0,  0,  0,  0}};
        static int[,] rookBoard ={
        { 0,  0,  0,  0,  0,  0,  0,  0},
        { 5, 10, 10, 10, 10, 10, 10,  5},
        {-5,  0,  0,  0,  0,  0,  0, -5},
        {-5,  0,  0,  0,  0,  0,  0, -5},
        {-5,  0,  0,  0,  0,  0,  0, -5},
        {-5,  0,  0,  0,  0,  0,  0, -5},
        {-5,  0,  0,  0,  0,  0,  0, -5},
        { 0,  0,  0,  5,  5,  0,  0,  0}};
        static int[,] knightBoard ={
        {-50,-40,-30,-30,-30,-30,-40,-50},
        {-40,-20,  0,  0,  0,  0,-20,-40},
        {-30,  0, 10, 15, 15, 10,  0,-30},
        {-30,  5, 15, 20, 20, 15,  5,-30},
        {-30,  0, 15, 20, 20, 15,  0,-30},
        {-30,  5, 10, 15, 15, 10,  5,-30},
        {-40,-20,  0,  5,  5,  0,-20,-40},
        {-50,-40,-30,-30,-30,-30,-40,-50}};
        static int[,] bishopBoard ={
        {-20,-10,-10,-10,-10,-10,-10,-20},
        {-10,  0,  0,  0,  0,  0,  0,-10},
        {-10,  0,  5, 10, 10,  5,  0,-10},
        {-10,  5,  5, 10, 10,  5,  5,-10},
        {-10,  0, 10, 10, 10, 10,  0,-10},
        {-10, 10, 10, 10, 10, 10, 10,-10},
        {-10,  5,  0,  0,  0,  0,  5,-10},
        {-20,-10,-10,-10,-10,-10,-10,-20}};
        static int[,] queenBoard ={
        {-20,-10,-10, -5, -5,-10,-10,-20},
        {-10,  0,  0,  0,  0,  0,  0,-10},
        {-10,  0,  5,  5,  5,  5,  0,-10},
        { -5,  0,  5,  5,  5,  5,  0, -5},
        {  0,  0,  5,  5,  5,  5,  0, -5},
        {-10,  5,  5,  5,  5,  5,  0,-10},
        {-10,  0,  5,  0,  0,  0,  0,-10},
        {-20,-10,-10, -5, -5,-10,-10,-20}};
        static int[,] kingMidBoard ={
        {-30,-40,-40,-50,-50,-40,-40,-30},
        {-30,-40,-40,-50,-50,-40,-40,-30},
        {-30,-40,-40,-50,-50,-40,-40,-30},
        {-30,-40,-40,-50,-50,-40,-40,-30},
        {-20,-30,-30,-40,-40,-30,-30,-20},
        {-10,-20,-20,-20,-20,-20,-20,-10},
        { 20, 20,  0,  0,  0,  0, 20, 20},
        { 20, 30, 10,  0,  0, 10, 30, 20}};
        static int[,] kingEndBoard ={
        {-50,-40,-30,-20,-20,-30,-40,-50},
        {-30,-20,-10,  0,  0,-10,-20,-30},
        {-30,-10, 20, 30, 30, 20,-10,-30},
        {-30,-10, 30, 40, 40, 30,-10,-30},
        {-30,-10, 30, 40, 40, 30,-10,-30},
        {-30,-10, 20, 30, 30, 20,-10,-30},
        {-30,-30,  0,  0,  0,  0,-30,-30},
        {-50,-30,-30,-30,-30,-30,-30,-50}};

        public static int evaluate(int list, int depth)
        {
            Bench.chamadas[Bench.EVALUATE]++;

            Bench.ms[Bench.EVALUATE].Start();

            Bench.msAux[Bench.EVALUATE].Restart();

            BoardGeneration.getChessboardArray(Orion.WP, Orion.WN, Orion.WB, Orion.WR, Orion.WQ, Orion.WK, Orion.BP, Orion.BN, Orion.BB, Orion.BR, Orion.BQ, Orion.BK);

            int counter = 0, material = rateMaterial();
            counter += rateAttack();
            counter += material;
            counter += rateMoveablitly(list, depth, material);
            counter += ratePositional(material, true);
            BoardGeneration.flipBoard();
            material = rateMaterial();
            counter -= rateAttack();
            counter -= material;
            counter -= rateMoveablitly(list, depth, material);
            counter -= ratePositional(material, false);
            BoardGeneration.flipBoard();

            Bench.msAux[Bench.EVALUATE].Stop();
            Bench.ms[Bench.EVALUATE].Stop();
            Bench.MenorMaior(Bench.EVALUATE);
            Bench.evaluate.Add(Bench.msAux[Bench.EVALUATE].ElapsedTicks * 100);

            return -(counter + depth * 50);
        }
        public static int rateAttack()
        {
            Bench.chamadas[Bench.RATE_ATTACK]++;

            Bench.ms[Bench.RATE_ATTACK].Start();
            Bench.msAux[Bench.RATE_ATTACK].Restart();

            int counter = 0;
            int tempPositionW = BoardGeneration.kingPositionW;
            for (int i = 0; i < 64; i++)
            {
                switch (BoardGeneration.chessBoardAtual[i / 8, i % 8])
                {
                    case "P":
                        { BoardGeneration.kingPositionW = i; if (!BoardGeneration.kingSafe()) { counter -= 64; } }
                        break;
                    case "R":
                        { BoardGeneration.kingPositionW = i; if (!BoardGeneration.kingSafe()) { counter -= 500; } }
                        break;
                    case "N":
                        { BoardGeneration.kingPositionW = i; if (!BoardGeneration.kingSafe()) { counter -= 300; } }
                        break;
                    case "B":
                        { BoardGeneration.kingPositionW = i; if (!BoardGeneration.kingSafe()) { counter -= 300; } }
                        break;
                    case "Q":
                        { BoardGeneration.kingPositionW = i; if (!BoardGeneration.kingSafe()) { counter -= 900; } }
                        break;
                }
            }

            BoardGeneration.kingPositionW = tempPositionW;
            if (!BoardGeneration.kingSafe()) { counter -= 200; }

            Bench.ms[Bench.RATE_ATTACK].Stop();
            Bench.msAux[Bench.RATE_ATTACK].Stop();
            Bench.MenorMaior(Bench.RATE_ATTACK);

            return counter / 2;

        }
        public static int rateMaterial()
        {
            Bench.chamadas[Bench.RATE_MATERIAL]++;

            Bench.ms[Bench.RATE_MATERIAL].Start();

            Bench.msAux[Bench.RATE_MATERIAL].Restart();

            int counter = 0, bishopCounter = 0;
            for (int i = 0; i < 64; i++)
            {
                switch (BoardGeneration.chessBoardAtual[i / 8, i % 8])
                {
                    case "P":
                        counter += 100;
                        break;
                    case "R":
                        counter += 500;
                        break;
                    case "N":
                        counter += 300;
                        break;
                    case "B":
                        bishopCounter += 1;
                        break;
                    case "Q":
                        counter += 900;
                        break;
                }
            }
            if (bishopCounter >= 2)
            {
                counter += 300 * bishopCounter;
            }
            else
            {
                if (bishopCounter == 1) { counter += 250; }
            }

            Bench.ms[Bench.RATE_MATERIAL].Stop();
            Bench.msAux[Bench.RATE_MATERIAL].Stop();
            Bench.MenorMaior(Bench.RATE_MATERIAL);

            return counter;
        }
        public static int rateMoveablitly(int listLength, int depth, int material)
        {
            Bench.chamadas[Bench.RATE_MOVEABLITLY]++;

            Bench.ms[Bench.RATE_MOVEABLITLY].Start();

            Bench.msAux[Bench.RATE_MOVEABLITLY].Restart();

            int counter = 0;
            counter += listLength;//5 pointer per valid move
            if (listLength == 0)
            {//current side is in checkmate or stalemate

                if (!BoardGeneration.kingSafe())
                {//if checkmate
                    counter += -200000 * depth;
                }

                else
                {//if stalemate
                    counter += -150000 * depth;
                }
            }

            Bench.ms[Bench.RATE_MOVEABLITLY].Stop();
            Bench.msAux[Bench.RATE_MOVEABLITLY].Stop();
            Bench.MenorMaior(Bench.RATE_MOVEABLITLY);

            return 0;
        }
        public static int ratePositional(int material, bool flip)
        {
            Bench.chamadas[Bench.RATE_POSITIONAL]++;

            Bench.ms[Bench.RATE_POSITIONAL].Start();

            Bench.msAux[Bench.RATE_POSITIONAL].Restart();

            int counter = 0;
            for (int i = 0; i < 64; i++)
            {
                switch (BoardGeneration.chessBoardAtual[i / 8, i % 8])
                {
                    case "P":
                        counter += pawnBoard[i / 8, i % 8];
                        break;
                    case "R":
                        counter += rookBoard[i / 8, i % 8];
                        break;
                    case "N":
                        counter += knightBoard[i / 8, i % 8];
                        break;
                    case "B":
                        counter += bishopBoard[i / 8, i % 8];
                        break;
                    case "Q":
                        counter += queenBoard[i / 8, i % 8];
                        break;
                    case "K":
                        if (material >= 1750)
                        {
                            counter += kingMidBoard[i / 8, i % 8];
                            counter += Moves.possibleK(Moves.OCCUPIED, flip ? Orion.WK : Orion.BK).Length * 10;

                        }
                        else
                        { counter += kingEndBoard[i / 8, i % 8]; counter += Moves.possibleK(Moves.OCCUPIED, flip ? Orion.WK : Orion.BK).Length * 30; }
                        break;
                }
            }

            Bench.ms[Bench.RATE_POSITIONAL].Stop();
            Bench.msAux[Bench.RATE_POSITIONAL].Stop();
            Bench.MenorMaior(Bench.RATE_POSITIONAL);

            return counter;

        }

    }
}